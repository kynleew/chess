package services;

import dataAccess.AuthDAO;
import dataAccess.DataAccessException;
import dataAccess.UserDAO;
import models.AuthToken;
import models.User;
import request.LoginRequest;
import result.LoginResult;
import result.RegisterResult;

import java.util.Objects;

/**
 * LoginSerive is where you attempt to login
 */
public class LoginService {

    /**
     *
     * @param request holds information to be able to login: username, password
     * @return if it was successful or not
     */
    public LoginResult login(LoginRequest request) throws DataAccessException {
        User user = new User (request.getUsername(), request.getPassword());
        UserDAO userDAO = UserDAO.getInstance();
        LoginResult result = new LoginResult();
        User oldUser = userDAO.find(user);

        if(oldUser == null){
            result.setMessage("Error: unauthorized");
        }
        else if(!Objects.equals(request.getPassword(), oldUser.getPassword())){
            result.setMessage("Error: unauthorized");
        }
        //Also check if there is no auth token^
        else if(userDAO.find(user) != null){
            AuthToken authToken = new AuthToken(user.getUsername());
            AuthDAO authDAO = AuthDAO.getInstance();
            authDAO.CreateToken(authToken);
            result.setAuthToken(authToken.getAuthToken());
            result.setUsername(request.getUsername());
            result.setMessage("");
        }
        return result;
    }
}
