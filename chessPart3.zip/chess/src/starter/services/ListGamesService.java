package services;

import dataAccess.AuthDAO;
import dataAccess.DataAccessException;
import dataAccess.GameDAO;
import dataAccess.UserDAO;
import models.AuthToken;
import models.Game;
import models.User;
import result.ListGameResult;
import result.LoginResult;

import java.util.HashSet;
import java.util.Objects;

/**
 * ListGameService is where you get try to list the games
 */
public class ListGamesService {

    /**
     * @return the result of getting the list, either fail or success
     */
    public ListGameResult listGame(String headers) throws DataAccessException {
        GameDAO gameDAO = GameDAO.getInstance();
        ListGameResult result = new ListGameResult();
        AuthDAO authDAO = AuthDAO.getInstance();
        HashSet<Game> games = gameDAO.findAll();

        if(authDAO.find(headers) == null){
            result.setMessage("Error: unauthorized");
        }
        else if(games != null){
            result.setGames(games);
            result.setMessage("");
        }
        return result;
    }
}
