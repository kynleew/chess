package models;

import java.util.UUID;

/**
 * AuthToken Class holds the username and the related authentication token
 */
public class AuthToken {
    //Global variables
    String authToken;
    String username;

    /**
     * Creates an AuthToken
     * @param username the username of the person trying to log in
     */

    public AuthToken(String username) {
        //UUID class to generate a new authToken
        UUID uuid = UUID.randomUUID();
        this.authToken = uuid.toString();
        this.username = username;
    }

    public String getAuthToken() {
        return authToken;
    }

    public String getUsername() {
        return username;
    }
}
