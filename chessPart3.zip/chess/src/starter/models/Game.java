package models;
import chess.ChessGame;
import chess.ChessGameImp;
import java.security.SecureRandom;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Game is where we keep track of the teamColor and the player
 * that is related to that color.
 */
public class Game {
    int gameID = IdCounter.nextId();
    String whiteUsername;
    String blackUsername;
    String gameName;
    ChessGame game;

    public static class IdCounter {
        private static int counter = 0;

        public static synchronized int nextId() {
            return ++counter;
        }
    }

    /**
     * Creates a new Game with the users
//     * @param gameID is the unique number of the individual game
//     * @param whiteUsername assigns a players username to white
//     * @param blackUsername assigns a players username to black
//     * @param game is the specific ChessGame that the two players are playing on
     */
    public Game(String gameName) {
        whiteUsername = null;
        blackUsername = null;
        game = new ChessGameImp();
        this.gameName = gameName;
    }

    public void setWhiteUsername(String whiteUsername) {
        this.whiteUsername = whiteUsername;
    }

    public void setBlackUsername(String blackUsername) {
        this.blackUsername = blackUsername;
    }

    public int getGameID() {
        return gameID;
    }

    public String getWhiteUsername() {
        return whiteUsername;
    }

    public String getBlackUsername() {
        return blackUsername;
    }

    public ChessGame getGame() {
        return game;
    }
}
