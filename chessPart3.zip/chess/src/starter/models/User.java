package models;

/**
 * User keeps track of the users username, password, and email. It is the
 * personal information that is related to their account
 */
public class User {
    private String username;
    private String password;
    private String email;

    /**
     * Creates a new user
     * @param username the unique name of each player
     * @param password the password to their account
//     * @param email the email that is related to their account
     */
    public User(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public String getEmail() {
        return email;
    }
}
