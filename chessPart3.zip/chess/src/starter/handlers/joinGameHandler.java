package handlers;

import com.google.gson.Gson;
import request.JoinGameRequest;
import request.RegisterRequest;
import result.JoinGameResult;
import result.RegisterResult;
import services.JoinGameService;
import services.RegisterService;
import spark.Request;
import spark.Response;
import spark.Route;

import java.util.Objects;

public class joinGameHandler implements Route {
    @Override
    public Object handle(Request request, Response response) throws Exception {
        String requestBody = request.body();
        Gson gson = new Gson();
        String headers = request.headers("authorization");


        JoinGameRequest request1 = gson.fromJson(requestBody, JoinGameRequest.class);
        JoinGameResult result = new JoinGameService().joinGame(request1, headers);
        if(result.getMessage().isEmpty()){
            response.status(200);
        }
        else if(Objects.equals(result.getMessage(), "Error: bad request")){
            response.status(400);
        }
        else if(Objects.equals(result.getMessage(), "Error: unauthorized")){
            response.status(401);
        }
        else if(Objects.equals(result.getMessage(), "Error: already taken")){
            response.status(403);
        }
        else if(Objects.equals(result.getMessage(), "Error: description")){
            response.status(500);
        }
        return gson.toJson(result);
    }
}
