package result;

/**
 * This class holds the result of if a login was successful or a failure
 */

public class LoginResult {
    private String message;
    private String authToken;
    private String username;

    /**
     * Creates a new instance of a result
     */
    public LoginResult(){}

    /**
     *
     * @return the message of success or failure
     */
    public String getMessage() {
        return message;
    }

    /**
     *
     * @param message sets the message to be success or failure
     */
    public void setMessage(String message) {
        this.message = message;
    }

    /**
     *
     * @return the authToken
     */
    public String getAuthToken() {
        return authToken;
    }

    /**
     *
     * @param authToken that is needed to login
     */
    public void setAuthToken(String authToken) {
        this.authToken = authToken;
    }

    /**
     *
     * @return the username that tried to login
     */
    public String getUsername() {
        return username;
    }

    /**
     *
     * @param username is the person who tried to login
     */
    public void setUsername(String username) {
        this.username = username;
    }
}
