package result;

/**
 * LogoutResult holds the result of the attempt to logout
 */
public class LogoutResult {
    String message;

    /**
     * Creates a new instance of logging out
     */
    public LogoutResult() {
    }

    /**
     *
     * @return the message of success or failure
     */
    public String getMessage() {
        return message;
    }

    /**
     *
     * @param message the message of success or failure
     */
    public void setMessage(String message) {
        this.message = message;
    }
}
