package dataAccess;

import models.AuthToken;
import models.Game;
import models.User;

import java.util.HashSet;
import java.util.Objects;

public class AuthDAO {
    HashSet<AuthToken>AuthTokensDatabase = new HashSet<>();
    private AuthDAO(){}

    private static class AuthDAOHelper{
        private static final AuthDAO INSTANCE = new AuthDAO();
    }

    public static AuthDAO getInstance(){
        return AuthDAO.AuthDAOHelper.INSTANCE;
    }
    /**
     * AuthDAO stores and retrieves the authentication related data from our server.
     */



    /**
     * CreateToken creates a new authentication token for each user.
     * @param token is needed to create the token
     * @throws DataAccessException is used if there is an exception such as, there
     * is nothing to remove, clear, find, or create.
     */
    public void CreateToken(AuthToken token) throws DataAccessException{
        AuthTokensDatabase.add(token);
    }

    /**
     * Looks up a authToken
     * @return the authToken
     * @throws DataAccessException indicates there was an error with find
     */
    public AuthToken find(String token) throws DataAccessException{
        for(AuthToken aToken: AuthTokensDatabase){
            if(Objects.equals(aToken.getAuthToken(), token)){
                return aToken;
            }
        }
        return null;
    }

    /**
     * Finds all the authTokens that exist
     * @return returns the authTokens in a set
     * @throws DataAccessException indicates there was an error with findAll
     */
    HashSet<AuthToken> findAll() throws DataAccessException{return AuthTokensDatabase;}

    /**
     *Removes all the authTokens that exist
     * @throws DataAccessException indicates there was an error with remove
     */
    public void remove(String token) throws DataAccessException{
        AuthTokensDatabase.removeIf(aToken -> Objects.equals(aToken.getAuthToken(), token));
    }

    /**
     * Clears all the authTokens that exist in the database
     * @throws DataAccessException indicates there was an error with clear
     */
    public void clear() throws DataAccessException{
        AuthTokensDatabase.clear();
    }

}
