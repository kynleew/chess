package dataAccess;

import chess.ChessGame;
import models.Game;
import models.User;

import java.util.*;

/**
 * GameDAO is where you update the game and ger information related to the game.
 */
public class GameDAO {
    HashSet<Game>gameDatabase = new HashSet<>();
    HashMap<Game, List<String>> observers = new HashMap<>();
    private GameDAO(){}

    private static class GameDAOHelper{
        private static final GameDAO INSTANCE = new GameDAO();
    }

    public static GameDAO getInstance(){
        return GameDAO.GameDAOHelper.INSTANCE;
    }

    /**
     * Creates a new game to play
     * @param game is the current game the players are playing on
     * @throws DataAccessException indicates there was an error creating a game
     */
    public void CreateGame(Game game) throws DataAccessException{
        gameDatabase.add(game);
    }

    /**
     * Find the specfic game you are playing
     * @return the game that you found
     * @throws DataAccessException indicates there was an error in finding the game
     */
    public Game find(int gameID) throws DataAccessException{
        for(Game game: gameDatabase){
            if(Objects.equals(game.getGameID(), gameID)){
                return game;
            }
        }
        return null;
    }

    /**
     * Finds all games that exist
     * @return a set of the games you are playing
     * @throws DataAccessException indicates there was an error in finding all the games
     */
    public HashSet<Game> findAll() throws DataAccessException{
        return gameDatabase;
    }

    /**
     * Claims a spot in a game
     * @throws DataAccessException indicates there was an error in claiming a spot
     */
    public void claimSpot(String username, String color, int gameID) throws DataAccessException{
        Game game = find(gameID);
        if(Objects.equals(color, "WHITE")){
            game.setWhiteUsername(username);
        }
        else if (Objects.equals(color, "BLACK")){
            game.setBlackUsername(username);
        }
        //if map.getGame is null create a new list map.put(list)
        else{
            observers.computeIfAbsent(game, k -> new ArrayList<String>());
            observers.get(game).add(username);
        }

    }

    /**
     * Updates the game with new players and teams
     * @throws DataAccessException indicates there was an error in updating game
     */
    void updateGame() throws DataAccessException{

    }

    /**
     * Removes a game after it is finished
     * @throws DataAccessException indicates there was an error in removing
     */
    void remove(int gameID) throws DataAccessException{
        for(Game game : gameDatabase){
            if(game.getGameID() == gameID){
                gameDatabase.remove(game);
            }
        }
    }

    /**
     * Clears all the games from the database
     * @throws DataAccessException indicates there was an error in clearing the game
     */
    public void clear() throws DataAccessException{
        gameDatabase.clear();
    }
}
