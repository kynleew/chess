package dataAccess;

import models.User;

import java.util.HashSet;
import java.util.Objects;

/**
 * Keeps track of specific users
 */
public class UserDAO {
    /**
     * Creates a new userDAO instance
     */
    HashSet<User>userDatabase = new HashSet<>();

    private UserDAO(){}

    private static class UserDAOHelper{
        private static final UserDAO INSTANCE = new UserDAO();
    }

    public static UserDAO getInstance(){
        return UserDAO.UserDAOHelper.INSTANCE;
    }

    /**
     * Creates the actual User
     * @param u is type User which stores all the users personal information
     * @throws DataAccessException indicates there was an error in creating the user
     */
    public void CreateUser(User u) throws DataAccessException{
        // take in the user and add it to the hashSet
        userDatabase.add(u);

    }

    /**
     * finds the user
     * @return the user that is found
     * @throws DataAccessException indicates there was an error in finding the user
     */
    public User find(User u) throws DataAccessException{
        for(User user: userDatabase){
            if(Objects.equals(user.getUsername(), u.getUsername())){
                return user;
            }
        }
        return null;
    }

    /**
     * Clears all the users from our database
     * @throws DataAccessException indicates there was an error in clearing the user
     */
    public void clear() throws DataAccessException{
        userDatabase.clear();
    }


}
