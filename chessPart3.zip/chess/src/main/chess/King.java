package chess;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

public class King implements ChessPiece {
    ChessGameImp.TeamColor color;
    Set<ChessPosition> temp = new HashSet<>();
    Collection<ChessMove> moves = new HashSet<>();

    public King(ChessGameImp.TeamColor color){
        this.color = color;
    }
    @Override
    public ChessGameImp.TeamColor getTeamColor() {
        return color;
    }

    @Override
    public PieceType getPieceType() {
        return PieceType.KING;
    }

    @Override
    public Collection<ChessMove> pieceMoves(ChessBoard board, ChessPosition myPosition) {
        int row = myPosition.getRow();
        int col = myPosition.getColumn();
        temp.clear();
//        checkMoves(board,row,col,0,0);
        checkMoves(board,row,col,1,0);
        checkMoves(board,row,col,1,1);
        checkMoves(board,row,col,0,1);
        checkMoves(board,row,col,-1,0);
        checkMoves(board,row,col,-1,-1);
        checkMoves(board,row,col,0,-1);
        checkMoves(board,row,col,-1,1);
        checkMoves(board,row,col,1,-1);
        Collection<ChessMove> thisMoves = new HashSet<>();
        for(ChessPosition position: temp){
            ChessMoveImp move = new ChessMoveImp(myPosition, position, null);
            thisMoves.add(move);
        }
        return thisMoves;
    }
    private void checkMoves(ChessBoard board, int row, int col, int x, int y){
        if(row + x <= 0 || col + y <= 0) return;
        else if(row + x >= 9 || col + y >= 9) return;
        else if(row == 1 && x < 0) return;
        else if(row == 8 && x > 0) return;
        else if(col == 1 && y < 0) return;
        else if(col == 8 && y > 0) return;

        ChessPosition position = new ChessPositionImp(row+x,col+y);
        if(board.getPiece(position) == null){
            temp.add(position);
        }
        else if(board.getPiece(position).getTeamColor() != getTeamColor()){
            temp.add(position);
        }
    }
    private boolean check(ChessPosition position){
        //check all the other pieces to see if the move could put king in check
        //
        return false;
    }
    private boolean checkMate(ChessPosition position){
        //check to see if the king is in check
        //if there is no place to go out of check, then you lose
        return false;
    }
}
