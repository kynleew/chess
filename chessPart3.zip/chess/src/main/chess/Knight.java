package chess;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

public class Knight implements ChessPiece {
    ChessGameImp.TeamColor color;
    Set<ChessPosition> temp = new HashSet<>();
    Collection<ChessMove> moves = new HashSet<>();

    public Knight(ChessGameImp.TeamColor color){
        this.color = color;
    }
    @Override
    public ChessGameImp.TeamColor getTeamColor() {
        return color;
    }

    @Override
    public PieceType getPieceType() {
        return PieceType.KNIGHT;
    }

    @Override
    public Collection<ChessMove> pieceMoves(ChessBoard board, ChessPosition myPosition) {

        int row = myPosition.getRow();
        int col = myPosition.getColumn();
        temp.clear();
        if (board.getPiece(myPosition).getTeamColor() == ChessGame.TeamColor.WHITE) {
            checkMovesWhite(board, row, col, 1, 2);
            checkMovesWhite(board, row, col, 1, -2);
            checkMovesWhite(board, row, col, -1, 2);
            checkMovesWhite(board, row, col, -1, -2);
            checkMovesWhite(board, row, col, 2, 1);
            checkMovesWhite(board, row, col, 2, -1);
            checkMovesWhite(board, row, col, -2, 1);
            checkMovesWhite(board, row, col, -2, -1);
        } else if (board.getPiece(myPosition).getTeamColor() == ChessGame.TeamColor.BLACK) {
            checkMovesBlack(board, row, col, 1, 2);
            checkMovesBlack(board, row, col, 1, -2);
            checkMovesBlack(board, row, col, -1, 2);
            checkMovesBlack(board, row, col, -1, -2);
            checkMovesBlack(board, row, col, 2, -1);
            checkMovesBlack(board, row, col, 2, 1);
            checkMovesBlack(board, row, col, -2, 1);
            checkMovesBlack(board, row, col, -2, -1);
        }
        Collection<ChessMove> thisMoves = new HashSet<>();
        for(ChessPosition position: temp){
            ChessMoveImp move = new ChessMoveImp(myPosition, position, null);
            thisMoves.add(move);
        }
        return thisMoves;
    }

    private void checkMovesWhite(ChessBoard board, int row, int col, int x, int y){
        if(row + x <= 0 || col + y <= 0) return;
        else if(row + x >= 9 || col + y >= 9) return;
        else if(row == 1 && x < 0) return;
        else if(row == 8 && x > 0) return;
        else if(col == 1 && y < 0) return;
        else if(col == 8 && y > 0) return;
        ChessPosition position = new ChessPositionImp(row+x,col+y);
        if(board.getPiece(position) == null){
            temp.add(position);
        }
        else if(board.getPiece(position).getTeamColor() != getTeamColor()){
            temp.add(position);
        }
    }
    private void checkMovesBlack(ChessBoard board, int row, int col, int x, int y){
        if(row + x <= 0 || col + y <= 0) return;
        else if(row + x >= 9 || col + y >= 9) return;
        else if(row == 1 && x < 0) return;
        else if(row == 8 && x > 0) return;
        else if(col == 1 && y < 0) return;
        else if(col == 8 && y > 0) return;
        ChessPosition position = new ChessPositionImp(row+x,col+y);
        if(board.getPiece(position) == null){
            temp.add(position);
        }
        else if(board.getPiece(position).getTeamColor() != getTeamColor()){
            temp.add(position);
        }
    }
}
