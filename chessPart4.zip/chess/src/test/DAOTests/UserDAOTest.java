package DAOTests;

import dataAccess.DataAccessException;
import dataAccess.UserDAO;
import models.User;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class UserDAOTest {
    UserDAO user = UserDAO.getInstance();
    User u = null;

    @BeforeEach
    void setUp() throws DataAccessException {
        clear();
        u = new User("username", "password");
        u.setEmail("email123");
        user.CreateUser(u);
    }

    @Test
    void createUser() throws DataAccessException {
        User us = new User("testPerson", "password123");
        us.setEmail("test@test.com");
        user.CreateUser(us);
    }
    @Test
    void createUserNegative() throws DataAccessException {
        User newUser = new User("testPerson", "password123");
        newUser.setEmail("test@test.com");

        // Attempt to create a user with an existing username (duplicate), which should result in an exception
        user.CreateUser(newUser);

        // Assert that the CreateUSer method throws a DataAccessException
        Assertions.assertThrows(DataAccessException.class, () -> user.CreateUser(newUser));
    }
    @Test
    void find() throws DataAccessException {
        User foundUser = user.find(u);
        Assertions.assertEquals(foundUser.getUsername(), u.getUsername());
    }
    @Test
    void findNegative() throws DataAccessException {
        User newUser = new User("testPerson", "password123");

        // Attempt to find a user that doesn't exist in the database, which should return null
        User foundUser = user.find(newUser);

        // Assert that the foundUser is null
        assertNull(foundUser);
    }
    @Test
    void clear() throws DataAccessException {
        user.clear();
    }
}