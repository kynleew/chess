package DAOTests;

import dataAccess.AuthDAO;
import dataAccess.DataAccessException;
import models.AuthToken;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.HashSet;

import static org.junit.jupiter.api.Assertions.*;

class AuthDAOTest {
    AuthDAO auth = AuthDAO.getInstance();
    AuthToken token = null;
    @BeforeEach
    void setUp() throws DataAccessException {
        token = new AuthToken("McKynlee");
        auth.CreateToken(token);
    }

    @AfterEach
    void clear() throws DataAccessException {
        auth.clear();
    }

    @Test
    void createToken() throws DataAccessException {
        AuthToken myToken = new AuthToken("Pete");
        AuthDAO auth = AuthDAO.getInstance();
        auth.CreateToken(myToken);
        AuthToken foundToken = auth.find(myToken.getAuthToken());
        Assertions.assertEquals(foundToken.getUsername(), myToken.getUsername());
        Assertions.assertEquals(foundToken.getAuthToken(), myToken.getAuthToken());
    }
    @Test
    void createTokenNegative() throws DataAccessException {
        AuthToken myToken = new AuthToken("Pete");

        // Attempt to create the same token twice, which should result in an exception
        auth.CreateToken(myToken);

        // Try creating the same token again and assert that it throws a DataAccessException
        Assertions.assertThrows(DataAccessException.class, () -> auth.CreateToken(myToken));
    }



    @Test
    void find() throws DataAccessException {
        AuthToken thisToken = new AuthToken("Mr. Incredible");
        auth.CreateToken(thisToken);
        AuthToken found = auth.find(thisToken.getAuthToken());
        Assertions.assertEquals(found.getUsername(), thisToken.getUsername(), "Find the wrong token");
        Assertions.assertEquals(found.getAuthToken(), thisToken.getAuthToken());
    }
    @Test
    void findNegative() throws DataAccessException {
        AuthToken thisToken = new AuthToken("Token That Doesn't Exist");

        // Attempt to find a token that doesn't exist, which should result in a null return
        AuthToken found = auth.find(thisToken.getAuthToken());

        // Assert that the found token is null
        assertNull(found);
    }


    @Test
    void findAll() throws DataAccessException {
        HashSet<AuthToken>foundTokens = new HashSet<>();
        foundTokens = auth.findAll();
//        Assertions.assertEquals();
    }
    @Test
    void findAllNegative() throws DataAccessException {
        // Clear all tokens to ensure none exist in the database
        clear();

        // Attempt to findAll when there are no tokens, which should result in an empty set
        HashSet<AuthToken> foundTokens = auth.findAll();

        // Assert that the foundTokens set is empty
        assertTrue(foundTokens.isEmpty());
    }


    @Test
    void remove() throws DataAccessException {
        // Attempt to remove the token
        auth.remove(token.getAuthToken());

        // Attempt to find the removed token, which should return null
        AuthToken removedToken = auth.find(token.getAuthToken());

        // Assert that the removedToken is null, indicating that the token was removed
        assertNull(removedToken);
    }

    @Test
    void removeNegative() throws DataAccessException {
        // Attempt to remove a token that doesn't exist, which should have no effect
        auth.remove("NonExistentToken");

        // Attempt to find the removed token and assert that it's still not found
        AuthToken removedToken = auth.find("NonExistentToken");
        assertNull(removedToken);
    }
}