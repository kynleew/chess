package serverTests.serviceTests;
import chess.ChessGame;
import org.junit.jupiter.api.*;
import passoffTests.TestFactory;
import passoffTests.obfuscatedTestClasses.TestServerFacade;
import passoffTests.testClasses.TestModels;

@SuppressWarnings("unused")
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class ServiceTests {
    private static final int HTTP_OK = 200;
    private static final int HTTP_BAD_REQUEST = 400;
    private static final int HTTP_UNAUTHORIZED = 401;
    private static final int HTTP_FORBIDDEN = 403;

    private static TestModels.TestUser existingUser;
    private static TestModels.TestUser newUser;
    private static TestModels.TestCreateRequest createRequest;
    private static TestServerFacade serverFacade;
    private String existingAuth;

    @BeforeAll
    public static void init() {
        existingUser = new TestModels.TestUser();
        existingUser.username = "Brigham";
        existingUser.password = "Young";
        existingUser.email = "BYU@byu.net";
        newUser = new TestModels.TestUser();
        newUser.username = "testUser";
        newUser.password = "testPass";
        newUser.email = "testEmail";
        createRequest = new TestModels.TestCreateRequest();
        createRequest.gameName = "testGame";
        serverFacade = new TestServerFacade("localhost", TestFactory.getServerPort());
    }
    @BeforeEach
    public void setup() {
        serverFacade.clear();
        TestModels.TestRegisterRequest registerRequest = new TestModels.TestRegisterRequest();
        registerRequest.username = existingUser.username;
        registerRequest.password = existingUser.password;
        registerRequest.email = existingUser.email;
        TestModels.TestLoginRegisterResult regResult = serverFacade.register(registerRequest);
        existingAuth = regResult.authToken;
    }
    @Test
    @DisplayName("Login Success")
    public void successLogin() {
        TestModels.TestLoginRequest loginRequest = new TestModels.TestLoginRequest();
        loginRequest.username = existingUser.username;
        loginRequest.password = existingUser.password;
        TestModels.TestLoginRegisterResult loginResult = serverFacade.login(loginRequest);
        Assertions.assertTrue(loginResult.success, "Login not successful");
    }
    @Test
    @DisplayName("Login Fail")
    public void loginInvalidUser() {
        TestModels.TestLoginRequest loginRequest = new TestModels.TestLoginRequest();
        loginRequest.username = newUser.username;
        loginRequest.password = newUser.password;
        TestModels.TestLoginRegisterResult loginResult = serverFacade.login(loginRequest);
        Assertions.assertFalse(loginResult.success, "Login wasn't supposed to be successful");
    }
    @Test
    @DisplayName("Register Success")
    public void successRegister() {
        TestModels.TestRegisterRequest registerRequest = new TestModels.TestRegisterRequest();
        registerRequest.username = newUser.username;
        registerRequest.password = newUser.password;
        registerRequest.email = newUser.email;
        TestModels.TestLoginRegisterResult registerResult = serverFacade.register(registerRequest);
        Assertions.assertTrue(registerResult.success, "registration was not successful for new user.");
    }
    @Test
    @DisplayName("Register Fail")
    public void registerTwice() {
        TestModels.TestRegisterRequest registerRequest = new TestModels.TestRegisterRequest();
        registerRequest.username = existingUser.username;
        registerRequest.password = existingUser.password;
        registerRequest.email = existingUser.email;
        TestModels.TestLoginRegisterResult registerResult = serverFacade.register(registerRequest);
        Assertions.assertFalse(registerResult.success, "Register was not successful");
    }
    @Test
    @DisplayName("Logout Success")
    public void successLogout() {
        TestModels.TestResult result = serverFacade.logout(existingAuth);
        Assertions.assertTrue(result.success, "Logout was not successful");
    }
    @Test
    @DisplayName("Logout Fail")
    public void failLogout() {
        serverFacade.logout(existingAuth);
        TestModels.TestResult result = serverFacade.logout(existingAuth);
        Assertions.assertFalse(result.success, "Response didn't return not successful");

    }
    @Test
    @DisplayName("Create Success")
    public void goodCreate() {
        TestModels.TestCreateResult createResult = serverFacade.createGame(createRequest, existingAuth);
        Assertions.assertTrue(createResult.success, "Result did not return successful");
    }
    @Test
    @DisplayName("Create Fail")
    public void badAuthCreate() {
        serverFacade.logout(existingAuth);
        TestModels.TestCreateResult createResult = serverFacade.createGame(createRequest, existingAuth);
        Assertions.assertFalse(createResult.success, "Bad result didn't return not successful");
    }
    @Test
    @DisplayName("JoinGame Success")
    public void goodJoin() {
        TestModels.TestCreateResult createResult = serverFacade.createGame(createRequest, existingAuth);
        TestModels.TestJoinRequest joinRequest = new TestModels.TestJoinRequest();
        joinRequest.gameID = createResult.gameID;
        joinRequest.playerColor = ChessGame.TeamColor.WHITE;
        TestModels.TestResult joinResult = serverFacade.verifyJoinPlayer(joinRequest, existingAuth);
        Assertions.assertTrue(joinResult.success, "Request returned not successful");
    }
    @Test
    @DisplayName("JoinGame Fail")
    public void badAuthJoin() {
        TestModels.TestCreateResult createResult = serverFacade.createGame(createRequest, existingAuth);
        TestModels.TestJoinRequest joinRequest = new TestModels.TestJoinRequest();
        joinRequest.gameID = createResult.gameID;
        joinRequest.playerColor = ChessGame.TeamColor.WHITE;
        TestModels.TestResult joinResult = serverFacade.verifyJoinPlayer(joinRequest, existingAuth + "bad stuff");
        Assertions.assertFalse(joinResult.success, "Request didn't return not successful");
    }
    @Test
    @DisplayName("ListGames Success ")
    public void GamesList() {
        TestModels.TestRegisterRequest registerRequest = new TestModels.TestRegisterRequest();
        registerRequest.username = "test";
        registerRequest.password = "testytest";
        registerRequest.email = "test.test";
        TestModels.TestLoginRegisterResult userA = serverFacade.register(registerRequest);
        createRequest.gameName = "Lets do this";
        TestModels.TestCreateResult game1 = serverFacade.createGame(createRequest, userA.authToken);
        TestModels.TestListResult result = serverFacade.listGames(existingAuth);
        Assertions.assertTrue(result.success, "Result returned not successful.");
    }
    @Test
    @DisplayName("ListGames Fail")
    public void gamesList() {
        //register user to create game
        TestModels.TestRegisterRequest registerRequest = new TestModels.TestRegisterRequest();
        registerRequest.username = "test";
        registerRequest.password = "testytest";
        registerRequest.email = "test.test";
        TestModels.TestLoginRegisterResult userA = serverFacade.register(registerRequest);
        createRequest.gameName = "Lets do this";
        TestModels.TestCreateResult game1 = serverFacade.createGame(createRequest, userA.authToken);
        //logout
        serverFacade.logout(existingAuth);
        //list games
        TestModels.TestListResult listResult = serverFacade.listGames(existingAuth);
        Assertions.assertFalse(listResult.success, "List games failed");
    }
    @Test
    @DisplayName("Clear Success")
    public void clearData() {
        TestModels.TestRegisterRequest registerRequest = new TestModels.TestRegisterRequest();
        registerRequest.username = "Wanda";
        registerRequest.password = "Vision";
        registerRequest.email = "wanda@vision.marvel";
        serverFacade.register(registerRequest);
        TestModels.TestResult clearResult = serverFacade.clear();
        Assertions.assertTrue(clearResult.success, "Clear Response came back not successful");
    }
}