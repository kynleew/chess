package request;

/**
 * Holds the information of the request to register a user
 */
public class RegisterRequest {
    private String username;
    private String password;
    private String email;

    /**
     * Creates a new Register instance
     */
    public RegisterRequest(String username, String password, String email){
        this.username = username;
        this.password = password;
        this.email = email;
    }

    /**
     *
     * @return the new user username
     */
    public String getUsername() {
        return username;
    }

    /**
     *
     * @param username of the person signing up
     */
//    public void setUsername(String username) {
//        this.username = username;
//    }

    /**
     *
     * @return the password
     */
    public String getPassword() {
        return password;
    }

    /**
     *
     * @param password for user to sign up
     */
//    public void setPassword(String password) {
//        this.password = password;
//    }

    /**
     *
     * @return email of new user
     */
    public String getEmail() { return email; }

    /**
     *
     * @param email of new user
     */
//    public void setEmail(String email) { this.email = email; }
}
