package services;

import dataAccess.AuthDAO;
import dataAccess.DataAccessException;
import dataAccess.UserDAO;
import models.AuthToken;
import models.User;
import request.RegisterRequest;
import result.RegisterResult;
import spark.Spark;

/**
 * RegisterService is where you go to register a new user to play chess
 */
public class RegisterService {
    /**
     *
     * @param request holds the request to create a new user
     * @return if the request was successful or failed
     */
    public RegisterResult register(RegisterRequest request) throws DataAccessException {
        User newUser = new User (request.getUsername(), request.getPassword());
        newUser.setEmail(request.getEmail());
        AuthDAO authDAO = AuthDAO.getInstance();
        //Authtoken is used for logging 'sessions' time logged in or time the user has been created
        UserDAO userDAO = UserDAO.getInstance();
        RegisterResult result = new RegisterResult();
        if(request.getUsername() == null || request.getEmail() == null || request.getPassword() == null){
            result.setMessage("Error: bad request");
        }
        else if(userDAO.find(newUser) == null){
            userDAO.CreateUser(newUser);
            AuthToken authToken = new AuthToken(newUser.getUsername());
            authDAO.CreateToken(authToken);
            result.setAuthToken(authToken.getAuthToken());
            result.setUsername(request.getUsername());
            result.setMessage("");
        }
        else{
            result.setMessage("Error: already taken");
        }
        return result;
    }
}
