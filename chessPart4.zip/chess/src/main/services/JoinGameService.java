package services;

import chess.ChessGame;
import dataAccess.AuthDAO;
import dataAccess.DataAccessException;
import dataAccess.GameDAO;
import models.Game;
import request.JoinGameRequest;
import result.CreateGameResult;
import result.JoinGameResult;

import java.sql.SQLException;

/**
 * JoinGameServer is where you make the request and get the result of joining a new game
 */
public class JoinGameService {
    /**
     *
     * @param request is the request with all the information of joining a game: playerColor, gameID
     * @return if the request was successful or if it failed
     */
    public JoinGameResult joinGame(JoinGameRequest request, String headers) throws DataAccessException, SQLException {
        //Authtoken is used for logging 'sessions' time logged in or time the user has been created
        GameDAO gameDAO = GameDAO.getInstance();
        JoinGameResult result = new JoinGameResult();
        AuthDAO authDAO = AuthDAO.getInstance();

        if(gameDAO.find(request.getGameID()) == null){
            result.setMessage("Error: bad request");
        }
        else if(authDAO.find(headers) == null){
            result.setMessage("Error: unauthorized");
        }
        else if((gameDAO.find(request.getGameID()).getWhiteUsername() != null) && (gameDAO.find(request.getGameID()).getBlackUsername() != null)){
            result.setMessage("Error: already taken");
        }
        else if(request.getPlayerColor() == ChessGame.TeamColor.WHITE){
            if(gameDAO.find(request.getGameID()).getWhiteUsername() == null){
                gameDAO.claimSpot(authDAO.find(headers).getUsername(), "WHITE", request.getGameID());
                result.setMessage("");
            }
            else{
                result.setMessage("Error: already taken");
            }
        }
        else if(request.getPlayerColor() == ChessGame.TeamColor.BLACK){
            if(gameDAO.find(request.getGameID()).getBlackUsername() == null){
                gameDAO.claimSpot(authDAO.find(headers).getUsername(), "BLACK", request.getGameID());
                result.setMessage("");
            }
            else{
                result.setMessage("Error: already taken");
            }
        }
        else if(request.getPlayerColor() == null){
            gameDAO.claimSpot(authDAO.find(headers).getUsername(), null, request.getGameID());
            result.setMessage("");
        }

        return result;
    }
}
