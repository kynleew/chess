package chess;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

public class Pawn implements ChessPiece {

    ChessGameImp.TeamColor color;
    Set<ChessPosition> temp = new HashSet<>();

    public Pawn(ChessGameImp.TeamColor color) {
        this.color = color;
    }

    @Override
    public ChessGameImp.TeamColor getTeamColor() {
        return color;
    }

    @Override
    public PieceType getPieceType() {
        return PieceType.PAWN;
    }

    @Override
    public Collection<ChessMove> pieceMoves(ChessBoard board, ChessPosition myPosition) {
        int row = myPosition.getRow();
        int col = myPosition.getColumn();
        temp.clear();
        if (board.getPiece(myPosition).getTeamColor() == ChessGame.TeamColor.WHITE) {
            checkMovesWhite(board, row, col, 1, 0);
            checkMovesWhite(board, row, col, 1, 1);
            checkMovesWhite(board, row, col, 1, -1);
        } else if (board.getPiece(myPosition).getTeamColor() == ChessGame.TeamColor.BLACK) {
            checkMovesBlack(board, row, col, -1, 0);
            checkMovesBlack(board, row, col, -1, -1);
            checkMovesBlack(board, row, col, -1, 1);
        }
        Collection<ChessMove> moves = new HashSet<>();
        for (ChessPosition position : temp) {
            if (board.getPiece(myPosition).getTeamColor() == ChessGame.TeamColor.WHITE) {
                if (row == 7) {
                    ChessMoveImp moveToQueen = new ChessMoveImp(myPosition, position, PieceType.QUEEN);
                    moves.add(moveToQueen);
                    ChessMoveImp moveToRook = new ChessMoveImp(myPosition, position, PieceType.ROOK);
                    moves.add(moveToRook);
                    ChessMoveImp moveToKnight = new ChessMoveImp(myPosition, position, PieceType.KNIGHT);
                    moves.add(moveToKnight);
                    ChessMoveImp moveToBishop = new ChessMoveImp(myPosition, position, PieceType.BISHOP);
                    moves.add(moveToBishop);
                }else {
                    ChessMoveImp move = new ChessMoveImp(myPosition, position, null);
                    moves.add(move);
                }
            }
            else if (board.getPiece(myPosition).getTeamColor() == ChessGame.TeamColor.BLACK) {
                if (row == 2) {
                    ChessMoveImp moveToQueen = new ChessMoveImp(myPosition, position, PieceType.QUEEN);
                    moves.add(moveToQueen);
                    ChessMoveImp moveToRook = new ChessMoveImp(myPosition, position, PieceType.ROOK);
                    moves.add(moveToRook);
                    ChessMoveImp moveToKnight = new ChessMoveImp(myPosition, position, PieceType.KNIGHT);
                    moves.add(moveToKnight);
                    ChessMoveImp moveToBishop = new ChessMoveImp(myPosition, position, PieceType.BISHOP);
                    moves.add(moveToBishop);
                }else {
                    ChessMoveImp move = new ChessMoveImp(myPosition, position, null);
                    moves.add(move);
                }
            }
        }
        return moves;
    }

    private void checkMovesWhite(ChessBoard board, int row, int col, int x, int y) {
        ChessPosition position = new ChessPositionImp(row+x, col+y);
        if(row + x <= 0 || col + y <= 0) return;
        else if(row + x >= 9 || col + y >= 9) return;
        else if(board.getPiece(position)!= null){
            if (board.getPiece(position).getTeamColor() == ChessGame.TeamColor.BLACK && y != 0) {
                temp.add(position);
            }
        }
        else if (y == 0) {
            temp.add(position);
            ChessPosition position1 = new ChessPositionImp(row+2, col);
            if (row == 2 && board.getPiece(position1) == null) {
                temp.add(position1);
            }
        }
    }

    private void checkMovesBlack(ChessBoard board, int row, int col, int x, int y) {
        ChessPosition position = new ChessPositionImp(row+x, col+y);
        if(row + x <= 0 || col + y <= 0) return;
        else if(row + x >= 9 || col + y >= 9) return;
        else if(board.getPiece(position) != null){
            if ((board.getPiece(position).getTeamColor() == ChessGame.TeamColor.WHITE) && (y != 0)) {
                temp.add(position);
            }
        }
        else if (y == 0) {
            temp.add(position);
            ChessPosition position1 = new ChessPositionImp(row-2, col);
            if (row == 7 && board.getPiece(position1) == null) {
                temp.add(position1);
            }
        }
    }
}
