package handlers;

import com.google.gson.Gson;
import request.CreateGameRequest;
import request.RegisterRequest;
import result.CreateGameResult;
import result.LogoutResult;
import result.RegisterResult;
import services.CreateGameService;
import services.LogoutService;
import services.RegisterService;
import spark.Request;
import spark.Response;
import spark.Route;

import java.util.Objects;

public class createGameHandler implements Route {
    @Override
    public Object handle(Request request, Response response) throws Exception {
        String requestBody = request.body();
        String headers = request.headers("authorization");

        Gson gson = new Gson();
        CreateGameRequest request1 = gson.fromJson(requestBody, CreateGameRequest.class);
        CreateGameResult result = new CreateGameService().creatGame(request1, headers);
        if(result.getMessage().isEmpty()){
            response.status(200);
        }
        else if(Objects.equals(result.getMessage(), "Error: bad request")){
            response.status(400);
        }
        else if(Objects.equals(result.getMessage(), "Error: unauthorized")){
            response.status(401);
        }
        else if(Objects.equals(result.getMessage(), "Error: description")){
            response.status(500);
        }
        return gson.toJson(result);
    }
}
