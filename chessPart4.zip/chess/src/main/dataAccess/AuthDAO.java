package dataAccess;

import models.AuthToken;
import models.Game;
import models.User;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.Objects;

public class AuthDAO {
//    HashSet<AuthToken>AuthTokensDatabase = new HashSet<>();
    Database db = new Database();
    private AuthDAO(){}

    private static class AuthDAOHelper{
        private static final AuthDAO INSTANCE = new AuthDAO();
    }

    public static AuthDAO getInstance(){
        return AuthDAO.AuthDAOHelper.INSTANCE;
    }
    /**
     * AuthDAO stores and retrieves the authentication related data from our server.
     */

    /**
     * CreateToken creates a new authentication token for each user.
//     * @param token is needed to create the token
     * @throws DataAccessException is used if there is an exception such as, there
     * is nothing to remove, clear, find, or create.
     */

    public void CreateToken(AuthToken token) throws DataAccessException{
        var conn = db.getConnection();
        String selectStatement = "INSERT INTO chess.Auth (authToken, username) VALUES (?, ?)";
        try (var preparedStatement = conn.prepareStatement(selectStatement)) {
            preparedStatement.setString(1, token.getAuthToken());
            preparedStatement.setString(2, token.getUsername());
            preparedStatement.execute();
        } catch (SQLException ex) {
            throw new DataAccessException(ex.toString());
        } finally {
            db.returnConnection(conn);
        }
    }
    /**
     * Looks up a authToken
     * @return the authToken
     * @throws DataAccessException indicates there was an error with find
     */
    public AuthToken find(String token) throws DataAccessException{
        var conn = db.getConnection();
        AuthToken authToken = null;
        String selectStatement = "SELECT authToken, username FROM chess.Auth WHERE authToken = ?";
        try (var preparedStatement = conn.prepareStatement(selectStatement)) {
            preparedStatement.setString(1, token);
            try(ResultSet resultSet = preparedStatement.executeQuery()){
                if (resultSet.next()){
                    String username = resultSet.getString("username");
                    String tokenFromDB = resultSet.getString("authToken");
                    authToken = new AuthToken(username, tokenFromDB);
                }
            }
        } catch (SQLException ex) {
            throw new DataAccessException(ex.toString());
        } finally {
            db.returnConnection(conn);
        }
        return authToken;
    }
    /**
     * Finds all the authTokens that exist
     * @return returns the authTokens in a set
     * @throws DataAccessException indicates there was an error with findAll
     */
    public HashSet<AuthToken> findAll() throws DataAccessException{
        var conn = db.getConnection();
        HashSet<AuthToken>AllAuthTokens = new HashSet<>();

        String selectStatement = "SELECT authToken, username FROM chess.Auth";
        try (var preparedStatement = conn.prepareStatement(selectStatement)) {
            ResultSet resultSet = preparedStatement.executeQuery();
            while(resultSet.next()){
                String username = resultSet.getString("username");
                String tokenFromDB = resultSet.getString("authToken");
                AuthToken authToken = new AuthToken(username, tokenFromDB);
                AllAuthTokens.add(authToken);
            }
        } catch (SQLException ex) {
            throw new DataAccessException(ex.toString());
        } finally {
            db.returnConnection(conn);
        }
        return AllAuthTokens;
    }

    /**
     *Removes all the authTokens that exist
     * @throws DataAccessException indicates there was an error with remove
     */
    public void remove(String token) throws DataAccessException{
        var conn = db.getConnection();
        String selectStatement = "DELETE FROM chess.Auth WHERE authToken = ?";
        try (var preparedStatement = conn.prepareStatement(selectStatement)) {
            preparedStatement.setString(1, token);
            preparedStatement.execute();
        } catch (SQLException ex) {
            throw new DataAccessException(ex.toString());
        } finally {
            db.returnConnection(conn);
        }
    }

    /**
     * Clears all the authTokens that exist in the database
     * @throws DataAccessException indicates there was an error with clear
     */
    public void clear() throws DataAccessException{
        var conn = db.getConnection();
        String selectStatement = "DELETE FROM chess.Auth";
        try (var preparedStatement = conn.prepareStatement(selectStatement)) {
            preparedStatement.execute();
        } catch (SQLException ex) {
            throw new DataAccessException(ex.toString());
        } finally {
            db.returnConnection(conn);
        }
    }
}
