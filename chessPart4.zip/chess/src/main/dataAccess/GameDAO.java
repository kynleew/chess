package dataAccess;

import chess.ChessBoard;
import chess.ChessBoardImp;
import chess.ChessGame;
import com.google.gson.Gson;
import models.AuthToken;
import models.Game;
import models.User;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.*;

/**
 * GameDAO is where you update the game and ger information related to the game.
 */
public class GameDAO {
    Database db = new Database();
    private GameDAO(){}

    private static class GameDAOHelper{
        private static final GameDAO INSTANCE = new GameDAO();
    }

    public static GameDAO getInstance(){
        return GameDAO.GameDAOHelper.INSTANCE;
    }

    /**
     * Creates a new game to play
     * @param game is the current game the players are playing on
     * @throws DataAccessException indicates there was an error creating a game
     */
    public int CreateGame(Game game) throws DataAccessException{
        var conn = db.getConnection();
        Gson gson = new Gson();
        int gameID = 0;
        String selectStatement = "INSERT INTO chess.Game (chessGame, blackUsername, whiteUsername, gameName) VALUES (?, ?, ?, ?)";
        try (var preparedStatement = conn.prepareStatement(selectStatement, Statement.RETURN_GENERATED_KEYS)) {
            preparedStatement.setString(1, gson.toJson(game.getGame()));
            preparedStatement.setString(2, game.getBlackUsername());
            preparedStatement.setString(3, game.getWhiteUsername());
            preparedStatement.setString(4, game.getGameName());
            preparedStatement.execute();
            gameID = GameId(game);
        } catch (SQLException ex) {
            throw new DataAccessException(ex.toString());
        } finally {
            db.returnConnection(conn);
        }
        return gameID;
    }

    public int GameId(Game game) throws DataAccessException {
        var conn = db.getConnection();
        Gson gson = new Gson();
        int gameID = 0;
        String selectStatement = "SELECT gameID FROM chess.Game ORDER BY gameID DESC LIMIT 1";
        try (var preparedStatement = conn.prepareStatement(selectStatement)) {
            ResultSet resultSet = preparedStatement.executeQuery();
            if(resultSet.next()){
                gameID = resultSet.getInt("gameID");
                game.setGameID(gameID);
            }
        } catch (SQLException ex) {
            throw new DataAccessException(ex.toString());
        } finally {
            db.returnConnection(conn);
        }
        return gameID;
    }
    /**
     * Find the specfic game you are playing
     * @return the game that you found
     * @throws DataAccessException indicates there was an error in finding the game
     */
    public Game find(int gameID) throws DataAccessException{
        var conn = db.getConnection();
        Gson gson = new Gson();
        Game foundGame = null;
        String selectStatement = "SELECT gameName, blackUsername, whiteUsername, chessGame FROM chess.Game WHERE gameID = ?";
        try (var preparedStatement = conn.prepareStatement(selectStatement)) {
            preparedStatement.setInt(1, gameID);
            try(ResultSet resultSet = preparedStatement.executeQuery()){
                if (resultSet.next()){
                    String gameName = resultSet.getString("gameName");
                    String blackUser = resultSet.getString("blackUsername");
                    String whiteUser = resultSet.getString("whiteUsername");
                    ChessBoardImp game = gson.fromJson(resultSet.getString("chessGame"), ChessBoardImp.class);
                    foundGame = new Game(gameName,blackUser, whiteUser, game);
                }
            }
        } catch (SQLException ex) {
            throw new DataAccessException(ex.toString());
        } finally {
            db.returnConnection(conn);
        }
        return foundGame;
    }

    /**
     * Finds all games that exist
     * @return a set of the games you are playing
     * @throws DataAccessException indicates there was an error in finding all the games
     */
    public HashSet<Game> findAll() throws DataAccessException{
        var conn = db.getConnection();
        HashSet<Game>AllGames = new HashSet<>();
        Gson gson = new Gson();
        Game foundGame;

        String selectStatement = "SELECT gameName, blackUsername, whiteUsername, chessGame, gameID FROM chess.Game";
        try (var preparedStatement = conn.prepareStatement(selectStatement)) {
            ResultSet resultSet = preparedStatement.executeQuery();
            while(resultSet.next()){
                String gameName = resultSet.getString("gameName");
                String blackUser = resultSet.getString("blackUsername");
                String whiteUser = resultSet.getString("whiteUsername");
                ChessBoardImp game = gson.fromJson(resultSet.getString("chessGame"), ChessBoardImp.class);
                int gameID = resultSet.getInt("gameID");
                foundGame = new Game(gameName,blackUser, whiteUser, game);
                foundGame.setGameID(gameID);
                AllGames.add(foundGame);
            }
        } catch (SQLException ex) {
            throw new DataAccessException(ex.toString());
        } finally {
            db.returnConnection(conn);
        }
        return AllGames;
    }

    /**
     * Claims a spot in a game
     * @throws DataAccessException indicates there was an error in claiming a spot
     */
    public void claimSpot(String username, String color, int gameID) throws DataAccessException, SQLException {
        Game game = find(gameID);
        var conn = db.getConnection();
        String selectStatement;
        Boolean checkUserExists = false;
        String checkUser = "SELECT username FROM chess.User WHERE username = ?";
        try(var prepStatement = conn.prepareStatement(checkUser)){
            prepStatement.setString(1, username);
            ResultSet resultExists = prepStatement.executeQuery();
            if(resultExists.next()){
                if(resultExists.getString("username") != null){
                    checkUserExists = true;
                }
            }

        }
        if(checkUserExists){
            if(Objects.equals(color, "WHITE")) {
                selectStatement = "UPDATE chess.Game SET whiteUsername = ? WHERE gameID = ?";
                try (var preparedStatement = conn.prepareStatement(selectStatement)) {
                    preparedStatement.setString(1, username);
                    preparedStatement.setInt(2, gameID);
                    preparedStatement.executeUpdate();
                } catch (SQLException ex) {
                    throw new DataAccessException(ex.toString());
                }
            }
            else if (Objects.equals(color, "BLACK")) {
                selectStatement = "UPDATE chess.Game SET blackUsername = ? WHERE gameID = ?";
                try (var preparedStatement = conn.prepareStatement(selectStatement)) {
                    preparedStatement.setString(1, username);
                    preparedStatement.setInt(2, gameID);
                    preparedStatement.executeUpdate();
                } catch (SQLException ex) {
                    throw new DataAccessException(ex.toString());
                }
            }
//            else{
//                observers.computeIfAbsent(game, k -> new ArrayList<String>());
////                observers.get(game).add(username);
//                selectStatement = "INSERT INTO Observers (observerName, gameID) VALUES (?, ?)";
//                try(var preparedStatement = conn.prepareStatement(selectStatement)) {
//                    preparedStatement.setString(1, username);
//                    preparedStatement.setInt(2, gameID);
//                    preparedStatement.execute();
//                }
//                catch (SQLException ex){
//                    throw new DataAccessException(ex.toString());
//                }
//            }
        }


    }

    /**
     * Updates the game with new players and teams
     * @throws DataAccessException indicates there was an error in updating game
     */
    // OBVIOUSLY NOT FINISHED AND NEEDS TO BE FIXED LATER
    public void updateGame() throws DataAccessException{

    }

    /**
     * Removes a game after it is finished
     * @throws DataAccessException indicates there was an error in removing
     */
    public void remove(int gameID) throws DataAccessException{
        var conn = db.getConnection();
        String selectStatement = "DELETE FROM chess.Game WHERE gameID = ?";
        try (var preparedStatement = conn.prepareStatement(selectStatement)) {
            preparedStatement.setInt(1, gameID);
            preparedStatement.execute();
        } catch (SQLException ex) {
            throw new DataAccessException(ex.toString());
        } finally {
            db.returnConnection(conn);
        }
    }

    /**
     * Clears all the games from the database
     * @throws DataAccessException indicates there was an error in clearing the game
     */
    public void clear() throws DataAccessException{
        var conn = db.getConnection();
        String selectStatement = "DELETE FROM chess.Game";
        try (var preparedStatement = conn.prepareStatement(selectStatement)) {
            preparedStatement.execute();
            String resetStatement = "ALTER TABLE chess.Game AUTO_INCREMENT = 1";
            try (var prepareStatement = conn.prepareStatement(resetStatement)){
                prepareStatement.execute();
            }catch (SQLException ex){
                throw new DataAccessException(ex.toString());
            }
        } catch (SQLException ex) {
            throw new DataAccessException(ex.toString());
        } finally {
            db.returnConnection(conn);
        }
    }
}
