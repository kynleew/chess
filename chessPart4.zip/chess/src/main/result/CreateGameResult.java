package result;

/**
 * CreateGameResult tells us if creating the game was successful and sets the gameID
 */
public class CreateGameResult {
    String message;
    Integer gameID = null;

    /**
     * CreateGameResult initializes the new game result
     */
    public CreateGameResult() {

    }

    /**
     *
     * @return message of if it was successful in creating a game or not
     */
    public String getMessage() {
        return message;
    }

    /**
     *
     * @param message of if it was successful in creating a game or not
     */
    public void setMessage(String message) {
        this.message = message;
    }

    /**
     *
     * @return the new gameID
     */

    public int getGameID() {
        return gameID;
    }

    /**
     *
     * @param gameID is the way to identify which game it is
     */
    public void setGameID(int gameID) {
        this.gameID = gameID;
    }
}
