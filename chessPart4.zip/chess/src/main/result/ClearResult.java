package result;

/**
 * ClearResult tells you if clearing was successful or not
 */
public class ClearResult {
    String message;
    /**
     * The ClearResult constructor creates a new message, assigning it as null
     */
    public ClearResult() {
        message = null;
    }

    /**
     * @return message -> the message that tells you if it was successful or not
     */
    public String getMessage() {
        return message;
    }

    /**
     * @param message -> is assigning message to be the success or fail message
     */
    public void setMessage(String message) {
        this.message = message;
    }
}
