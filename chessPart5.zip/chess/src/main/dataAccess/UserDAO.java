package dataAccess;

import models.AuthToken;
import models.User;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashSet;

/**
 * Keeps track of specific users
 */
public class UserDAO {
    /**
     * Creates a new userDAO instance
     */
    HashSet<User>userDatabase = new HashSet<>();
    Database db = new Database();

    private UserDAO(){}

    private static class UserDAOHelper{
        private static final UserDAO INSTANCE = new UserDAO();
    }

    public static UserDAO getInstance(){
        return UserDAO.UserDAOHelper.INSTANCE;
    }

    /**
     * Creates the actual User
     * @param u is type User which stores all the users personal information
     * @throws DataAccessException indicates there was an error in creating the user
     */
    public void CreateUser(User u) throws DataAccessException{
        // take in the user and add it to the hashSet
        var conn = db.getConnection();
        String selectStatement = "INSERT INTO User (username, password, email) VALUES (?, ?, ?)";
        try (var preparedStatement = conn.prepareStatement(selectStatement)) {
            preparedStatement.setString(1, u.getUsername());
            preparedStatement.setString(2, u.getPassword());
            preparedStatement.setString(3, u.getEmail());
            preparedStatement.execute();
        } catch (SQLException ex) {
            throw new DataAccessException(ex.toString());
        } finally {
            db.returnConnection(conn);
        }
    }

    /**
     * finds the user
     * @return the user that is found
     * @throws DataAccessException indicates there was an error in finding the user
     */
    public User find(User u) throws DataAccessException{
        var conn = db.getConnection();
        User foundUser = null;
        String selectStatement = "SELECT username, password FROM chess.User WHERE username = ?";
        try (var preparedStatement = conn.prepareStatement(selectStatement)) {
            preparedStatement.setString(1, u.getUsername());
            try(ResultSet resultSet = preparedStatement.executeQuery()){
                if (resultSet.next()){
                    String username = resultSet.getString("username");
                    String password = resultSet.getString("password");
                    foundUser = new User(username, password);
                }
            }
        } catch (SQLException ex) {
            throw new DataAccessException(ex.toString());
        } finally {
            db.returnConnection(conn);
        }
        return foundUser;
    }

    /**
     * Clears all the users from our database
     * @throws DataAccessException indicates there was an error in clearing the user
     */
    public void clear() throws DataAccessException{
        var conn = db.getConnection();
        String selectStatement = "DELETE FROM chess.User";
        try (var preparedStatement = conn.prepareStatement(selectStatement)) {

            preparedStatement.execute();
        } catch (SQLException ex) {
            throw new DataAccessException(ex.toString());
        } finally {
            db.returnConnection(conn);
        }
    }


}
