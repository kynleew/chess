package handlers;

import com.google.gson.Gson;
import request.RegisterRequest;
import result.ClearResult;
import services.ClearService;
import spark.Request;
import spark.Response;
import spark.Route;

import java.util.Objects;

public class clearHandler implements Route {
    @Override
    public Object handle(Request request, Response response) throws Exception {
        String requestBody = request.body();
        Gson gson = new Gson();
        ClearResult result = new ClearService().clear();
        if(result.getMessage().isEmpty()){
            response.status(200);
        }
        else if(Objects.equals(result.getMessage(), "Error: description")){
            response.status(500);
        }
        return gson.toJson(result);
    }
}
