package handlers;

import com.google.gson.Gson;
import request.RegisterRequest;
import result.ListGameResult;
import services.ListGamesService;
import spark.Request;
import spark.Response;
import spark.Route;

import java.util.Objects;

public class listGameHandler implements Route {
    @Override
    public Object handle(Request request, Response response) throws Exception {
        Gson gson = new Gson();
        String headers = request.headers("authorization");
        ListGameResult result = new ListGamesService().listGame(headers);
        if(result.getMessage().isEmpty()){
            response.status(200);
        }
        else if(Objects.equals(result.getMessage(), "Error: unauthorized")){
            response.status(401);
        }
        else if(Objects.equals(result.getMessage(), "Error: description")){
            response.status(500);
        }
        return gson.toJson(result);
    }
}
