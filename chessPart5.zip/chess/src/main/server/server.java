package server;
import dataAccess.DataAccessException;
import handlers.*;
import models.AuthToken;
import spark.Spark;

public class server {
    String http_request;
    public server(String http_request) {
        this.http_request = http_request;
    }
    public static void main (String[] args) throws DataAccessException {
        int port = 8082;
        Spark.port(port);
        Spark.externalStaticFileLocation("web");
        //Set up endpoints
        Spark.post("/user", new registerHandler());
        Spark.post("/session", new loginHandler());
        Spark.post("/game", new createGameHandler());
        Spark.get("/game", new listGameHandler());
        Spark.put("/game", new joinGameHandler());
        Spark.delete("/session", new logoutHandler());
        Spark.delete("/db", new clearHandler());
        Spark.init();
    }
}
