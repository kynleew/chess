package services;

import dataAccess.AuthDAO;
import dataAccess.DataAccessException;
import models.AuthToken;
import models.User;
import result.LogoutResult;

/**
 * LogoutService is where you go to logout
 */
public class LogoutService {
    /**
     *
     * @return if it was successful or not
     */
    public LogoutResult logout(String authToken) throws DataAccessException {
        //Authtoken is used for logging 'sessions' time logged in or time the user has been created
        AuthDAO authDAO = AuthDAO.getInstance();
        LogoutResult result = new LogoutResult();
        if(authDAO.find(authToken) == null){
            result.setMessage("Error: unauthorized");
        }
        else{
            result.setMessage("");
            authDAO.remove(authToken);
        }
        return result;
    }
}
