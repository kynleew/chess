package services;

import dataAccess.AuthDAO;
import dataAccess.DataAccessException;
import dataAccess.GameDAO;
import dataAccess.UserDAO;
import models.AuthToken;
import models.Game;
import models.User;
import result.ClearResult;

public class ClearService {
    /**
     * The ClearService class will Clear all values in the database,
     * creates a ClearResult
     * @return a ClearResult that will identify if the clear was successful or not
     */

    //Maybe take in String message below????
    public ClearResult clear() throws DataAccessException {
        //Authtoken is used for logging 'sessions' time logged in or time the user has been created
        UserDAO userDAO = UserDAO.getInstance();
        GameDAO gameDAO = GameDAO.getInstance();
        AuthDAO authDAO = AuthDAO.getInstance();

        ClearResult result = new ClearResult();

        userDAO.clear();
        gameDAO.clear();
        authDAO.clear();

        result.setMessage("");

        return result;
    }
}
