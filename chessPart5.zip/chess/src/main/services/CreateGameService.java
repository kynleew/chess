package services;

import dataAccess.AuthDAO;
import dataAccess.DataAccessException;
import dataAccess.GameDAO;
import models.AuthToken;
import models.Game;
import models.User;
import request.CreateGameRequest;
import result.CreateGameResult;

/**
 * CreateGameService is where you go to create a new game
 */
public class CreateGameService {
    Game game;

    public CreateGameService() {

    }

    /**
     *
     * @param request is the information for creating a new game. Specifically gameName
     * @return returns CreateGameResult which will tell you if it was successful or not.
     */
    public CreateGameResult creatGame(CreateGameRequest request, String headers) throws DataAccessException {
        //Authtoken is used for logging 'sessions' time logged in or time the user has been created
        GameDAO gameDAO = GameDAO.getInstance();
        CreateGameResult result = new CreateGameResult();
        AuthDAO authDAO = AuthDAO.getInstance();

        if(authDAO.find(headers) == null){
            result.setMessage("Error: unauthorized");
        }
        else if(headers.isEmpty()){
            result.setMessage("Error: unauthorized");
        }
        else if(request.getGameName() == null){
            result.setMessage("Error: bad request");
        }
        else{
            game = new Game(request.getGameName());
            gameDAO.CreateGame(game);
            result.setGameID(game.getGameID());
            result.setMessage("");
        }
        return result;
    }

    public Game getGame() {
        return game;
    }
}
