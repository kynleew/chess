package DAOTests;

import chess.ChessGame;
import dataAccess.DataAccessException;
import dataAccess.GameDAO;
import dataAccess.UserDAO;
import models.Game;
import models.User;
import org.junit.jupiter.api.*;

import java.sql.SQLException;
import java.util.HashSet;

import static org.junit.jupiter.api.Assertions.*;

class GameDAOTest {
    GameDAO gameDAO = GameDAO.getInstance();
    Game game = null;
    int gameID;

    @BeforeEach
    void setUp() throws DataAccessException {
        gameDAO.clear();
        UserDAO user = UserDAO.getInstance();
        user.clear();
        User u = new User("whiteUser", "password");
        u.setEmail("email123");
        user.CreateUser(u);
        game = new Game("First Game");
        gameID = gameDAO.CreateGame(game);
    }

    @Test
    @Order(1)
    void createGame() throws DataAccessException {
        Game newGame = new Game("Best Game");
        newGame.setWhiteUsername("Perry");
        newGame.setBlackUsername("Dr. Doofenshmirtz");
        int gameid = gameDAO.CreateGame(newGame);
    }
    @Test
    @Order(1)
    void createGameNegative() throws DataAccessException {
        // Create a game with an invalid gameName that exceeds the maximum allowed length (over 50 characters)
        String invalidGameName = "ThisIsAnInvalidGameNameThatIsOver50CharactersInLength";

        Game newGame = new Game(invalidGameName);
        newGame.setWhiteUsername("Perry");
        newGame.setBlackUsername("Dr. Doofenshmirtz");

        // Attempt to create the game with an invalid gameName
        Assertions.assertThrows(DataAccessException.class, () -> {
            int gameid = gameDAO.CreateGame(newGame);
        });
    }




    @Test
    @Order(2)
    void find() throws DataAccessException {
        Game findGame = new Game("Find me");
        findGame.setWhiteUsername("Wanda");
        findGame.setBlackUsername("Vision");
        int gameID = gameDAO.CreateGame(findGame);
        Game found = gameDAO.find(gameID);
        Assertions.assertEquals(findGame.getBlackUsername(), found.getBlackUsername());
        Assertions.assertEquals(findGame.getWhiteUsername(), found.getWhiteUsername());
        Assertions.assertEquals(found.getGameName(), findGame.getGameName());
    }
    @Test
    @Order(2)
    void findNegative() throws DataAccessException {
        Game findGame = new Game("Find me");
        findGame.setWhiteUsername("Wanda");
        findGame.setBlackUsername("Vision");

        // Attempt to find a non-existent game, which should return null
        Game found = gameDAO.find(-1); // Provide an invalid game ID

        // Assert that the found game is null
        assertNull(found);
    }


    @Test
    @Order(3)
    void findAll() throws DataAccessException {
        find();
        HashSet<Game>gamesFound = new HashSet<>();
        gamesFound = gameDAO.findAll();
        Assertions.assertEquals(2, gamesFound.size());
    }
    @Test
    @Order(3)
    void findAllNegative() throws DataAccessException {
        // Clear all games to ensure none exist in the database
        gameDAO.clear();

        // Attempt to call findAll when there are no games, which should result in an empty set
        HashSet<Game> gamesFound = gameDAO.findAll();

        // Assert that the gamesFound set is empty
        assertTrue(gamesFound.isEmpty());
    }



    @Test
    @Order(4)
    void claimSpot() throws SQLException, DataAccessException {
        gameDAO.claimSpot("whiteUser", "WHITE", gameID);
        Assertions.assertEquals("whiteUser", gameDAO.find(gameID).getWhiteUsername());
    }
    @Test
    @Order(4)
    void claimSpotNegative() throws SQLException, DataAccessException {
        // First, create a game with an existing white username
        Game existingGame = new Game("Existing Game");
        User user = new User("harry potter", "ronweasly");
        User userDoof = new User("Dr. Doofenshmirtz", "perry");
        user.setEmail("email");
        userDoof.setEmail("userDoof.email");
        UserDAO userDAO = UserDAO.getInstance();
        userDAO.CreateUser(user);
        userDAO.CreateUser(userDoof);
        int existingGameID = gameDAO.CreateGame(existingGame);
        gameDAO.claimSpot("whiteUser", "WHITE", gameID);
        gameDAO.claimSpot("Dr. Doofenshmirtz", "BLACK", gameID);
        gameDAO.claimSpot("harry potter", "WHITE", gameID);

        // Assert that the game's state remains unchanged (whiteUsername should not be updated)
        Assertions.assertNotEquals("harry potter", gameDAO.find(existingGameID).getWhiteUsername());
    }




    @Test
    void updateGame() {
    }

    @Test
    @Order(5)
    void remove() throws DataAccessException {
        Game newGame1 = new Game("Best Game Ever");
        newGame1.setWhiteUsername("removeMe");
        newGame1.setBlackUsername("blackRemove");
        int gameid = gameDAO.CreateGame(newGame1);
        gameDAO.remove(gameid);
    }
    @Test
    @Order(5)
    void removeNegative() throws DataAccessException {
        // Attempt to remove a game with an invalid game ID, which should have no effect
        int invalidGameID = -1;
        gameDAO.remove(invalidGameID); // Provide an invalid game ID

        // Attempt to find the game with the invalid game ID, which should return null
        Game removedGame = gameDAO.find(invalidGameID);

        // Assert that the removedGame is null, indicating that the database remains unchanged
        assertNull(removedGame);
    }


}