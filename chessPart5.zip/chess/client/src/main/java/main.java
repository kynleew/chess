import client.Repl;
public class main {
    public static void main(String[] args){
        var serverURL = "http://localhost:8082";
        if(args.length == 1){
            serverURL = args[0];
        }
        new Repl(serverURL).run();
    }
}
