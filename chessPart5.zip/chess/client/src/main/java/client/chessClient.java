package client;

import chess.*;
import com.sun.nio.sctp.NotificationHandler;
import request.CreateGameRequest;
import request.JoinGameRequest;
import request.LoginRequest;
import request.RegisterRequest;
import result.CreateGameResult;
import result.ListGameResult;
import result.LoginResult;
import result.RegisterResult;
import server.ServerFacade;
//import com.google.gson.Gson;
import models.*;
import exception.ResponseException;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Objects;
import static ui.EscapeSequences.*;

//import client.websocket.NotificationHandler;
//import client.websocket.WebsocketFacade;
public class chessClient {
    private final ServerFacade server;
    private final String serverUrl;
    String authToken = null;
    private LoginResult loginResult;
    private final NotificationHandler notificationHandler;
    private State state = State.SIGNEDOUT;

    public chessClient(String serverUrl, NotificationHandler notificationHandler){
        server = new ServerFacade(serverUrl);
        this.serverUrl = serverUrl;
        this.notificationHandler = notificationHandler;
    }

    public String help() {
        if(state == State.SIGNEDIN){
            return """
                - help
                - logout
                - create <gameName>
                - list
                - join <gameID> <teamColor(white/black/empty)>
                """;
        }
        return """
                    - help
                    - login <yourUsername> <password>
                    - register <username> <password> <email>
                    - quit
                    """;
    }

    public String eval(String input) {
        try {
            var tokens = input.toLowerCase().split(" ");
            var cmd = (tokens.length > 0) ? tokens[0] : "help";
            var params = Arrays.copyOfRange(tokens, 1, tokens.length);
            return switch (cmd) {
                case "login" -> login(params);
                case "register" -> register(params);
                case "quit" -> "quit";
                case "logout" -> logout();
                case "create" -> createGame(params);
                case "list" -> listGames();
                case "join" -> joinGame(params);
                default -> help();
            };
        } catch(ResponseException ex) {
            return ex.getMessage();
        }
    }

    private String joinGame(String[] params) throws ResponseException{ //puts the game to console
        if(loginResult.getAuthToken() != null){
            if (params.length == 2){
                try{
                    if(Objects.equals(params[1], "white")){
                        server.joinGame(new JoinGameRequest(ChessGame.TeamColor.WHITE, Integer.parseInt(params[0])), loginResult.getAuthToken());
                        return printBoard("white");
                    }
                    else if(Objects.equals(params[1], "black")){
                        server.joinGame(new JoinGameRequest(ChessGame.TeamColor.BLACK, Integer.parseInt(params[0])), loginResult.getAuthToken());
                        return printBoard("black");
                    }
                    else if (Objects.equals(params[1], "observer")){
                        server.joinGame(new JoinGameRequest(null, Integer.parseInt(params[0])), loginResult.getAuthToken());
                        return printBoard("white");
                    }
                    else{
                        return "Please include what spot you want to take";
                    }
                } catch(ResponseException ex){
                    return "Did not join the game";
                }
            }else{
                return "Please include gameID and color you want to play";
            }
        }
        else{
            return "You can not join a game without logging in";
        }
    }

    private String listGames() throws ResponseException{
        if(loginResult.getAuthToken() != null){
            try{
                ListGameResult listOfGames = server.listGames(loginResult.getAuthToken());
                HashSet<Game> list = listOfGames.getGames();
                StringBuilder stringBuilder = new StringBuilder();
                for(Game game: list){
                    stringBuilder.append("\n" + "Game ID:").append(game.getGameID()).append("\nGame Name: ").append(game.getGameName()).append("\nWhite User: ").append(game.getWhiteUsername()).append("\nBlack User: ").append(game.getBlackUsername());
                }
                return String.valueOf(stringBuilder);
            }catch(ResponseException ex){
                return "You are not currently logged in";
            }
        }
        else{
            return "You are not currently logged in";
        }
    }

    private String createGame(String[] params) throws ResponseException{ //returns the id
        if(loginResult.getAuthToken() != null){
            if (params.length >= 1){
                StringBuilder stringBuilder = new StringBuilder();
                for(String param: params){
                    stringBuilder.append(param).append(" ");
                }
                try{
                    CreateGameResult game = server.createGame(new CreateGameRequest(String.valueOf(stringBuilder)), loginResult.getAuthToken());
                    return "Game \"" + stringBuilder + "\" has been created. \n GameId: " + game.getGameID();
                }catch(ResponseException ex){
                    return "Did not create a game";
                }
            }
            else{
                return "Please include a game name";
            }
        }else{
            return "You can not create a game without logging in";
        }
    }

    private String logout() throws ResponseException{
        if(loginResult.getAuthToken() != null){
            try{
                server.logout(loginResult.getAuthToken());
                state = State.SIGNEDOUT;
                return "You successfully logged out";
            }catch(ResponseException ex){
                return "You are not currently logged in";
            }
        }
        else{
            return "You are not currently logged in";
        }
    }

    private String register(String[] params) throws ResponseException{
        if (params.length == 3){
            try{
                server.registerUser(new RegisterRequest(params[0], params[1], params[2]));
                return "You Successfully Signed In as " + params[0] + ".";
            }catch(ResponseException ex){
                return "Invalid username, please choose a new username";
            }

        }
        else{
            return "You need to include username, password, and email";
        }
    }

    private String login(String[] params) throws ResponseException{
        if (params.length == 2){
            try{
                loginResult = server.login(new LoginRequest(params[0], params[1]));
                state = State.SIGNEDIN;
                return "You Successfully Signed In as " + params[0] + ".";
            }catch(ResponseException ex){
                return "Login Failed, username or password incorrect";
            }
        }
        else{
            return "You need to include username and password";
        }
    }

    public String printBoard(String color){
        ChessBoardImp board = new ChessBoardImp();
        board.resetBoard();
        StringBuilder output = new StringBuilder();
        if(Objects.equals(color, "black")){
            output.append(RESET_BG_COLOR + "\n" + SET_BG_COLOR_LIGHT_GREY + SET_TEXT_COLOR_WHITE + EMPTY +
                    " h " + " g " + " f " + " e " + " d " + " c " + " b " + " a " + EMPTY + "\n" + SET_BG_COLOR_WHITE);
            for(int i = 1; i < 9; i++){
                output.append(SET_BG_COLOR_LIGHT_GREY + SET_TEXT_COLOR_WHITE + " ").append(i).append(" ");
                for(int j = 8; j > 0; j--){
                    if(i%2 == 0){
                        if(j%2 == 0){
                            output.append(SET_BG_COLOR_DARK_GREY);
                        }
                        else {
                            output.append(SET_BG_COLOR_WHITE);
                        }
                    }
                    else{
                        if(j%2 == 1){
                            output.append(SET_BG_COLOR_DARK_GREY);
                        }
                        else {
                            output.append(SET_BG_COLOR_WHITE);
                        }
                    }
                    ChessPosition position = new ChessPositionImp(i, j);
                    ChessPiece piece = board.getPiece(position);
                    if(piece == null){
                        output.append(EMPTY);
                        continue;
                    }
                    else{
                        if(piece.getTeamColor() == ChessGame.TeamColor.WHITE){
                            switch(piece.getPieceType()){
                                case KING:
                                    output.append(SET_TEXT_COLOR_RED + WHITE_KING);
                                    break;
                                case QUEEN:
                                    output.append(SET_TEXT_COLOR_RED + WHITE_QUEEN);
                                    break;
                                case BISHOP:
                                    output.append(SET_TEXT_COLOR_RED + WHITE_BISHOP);
                                    break;
                                case KNIGHT:
                                    output.append(SET_TEXT_COLOR_RED + WHITE_KNIGHT);
                                    break;
                                case ROOK:
                                    output.append(SET_TEXT_COLOR_RED + WHITE_ROOK);
                                    break;
                                case PAWN:
                                    output.append(SET_TEXT_COLOR_RED + WHITE_PAWN);
                                    break;
                                default:
                                    output.append(SET_TEXT_COLOR_BLUE + EMPTY);
                                    break;
                            }
                        }
                        else if(piece.getTeamColor() == ChessGame.TeamColor.BLACK){
                            switch(piece.getPieceType()){
                                case KING:
                                    output.append(SET_TEXT_COLOR_BLACK + BLACK_KING);
                                    break;
                                case QUEEN:
                                    output.append(SET_TEXT_COLOR_BLACK + BLACK_QUEEN);
                                    break;
                                case BISHOP:
                                    output.append(SET_TEXT_COLOR_BLACK + BLACK_BISHOP);
                                    break;
                                case KNIGHT:
                                    output.append(SET_TEXT_COLOR_BLACK + BLACK_KNIGHT);
                                    break;
                                case ROOK:
                                    output.append(SET_TEXT_COLOR_BLACK + BLACK_ROOK);
                                    break;
                                case PAWN:
                                    output.append(SET_TEXT_COLOR_BLACK + BLACK_PAWN);
                                    break;
                                default:
                                    output.append(EMPTY);
                                    break;
                            }
                        }
                    }
                }
                output.append(SET_BG_COLOR_LIGHT_GREY + SET_TEXT_COLOR_WHITE + " ").append(i).append(" ").append("\n");
            }
            output.append(SET_BG_COLOR_LIGHT_GREY + SET_TEXT_COLOR_WHITE + EMPTY +
                    " h " + " g " + " f " + " e " + " d " + " c " + " b " + " a " + EMPTY + "\n");
        }
        else{ //white
            output.append(RESET_BG_COLOR + "\n" + SET_BG_COLOR_LIGHT_GREY + SET_TEXT_COLOR_WHITE + EMPTY +
                    " a " + " b " + " c " + " d " + " e " + " f " + " g " + " h " + EMPTY + "\n" + SET_BG_COLOR_WHITE);
            for(int i = 8; i > 0; i--){
                output.append(SET_BG_COLOR_LIGHT_GREY + SET_TEXT_COLOR_WHITE + " ").append(i).append(" ");
                for(int j = 1; j < 9; j++){
                    if(i%2 == 0){
                        if(j%2 == 0){
                            output.append(SET_BG_COLOR_WHITE);
                        }
                        else {
                            output.append(SET_BG_COLOR_DARK_GREY);
                        }
                    }
                    else{
                        if(j%2 == 1){
                            output.append(SET_BG_COLOR_WHITE);
                        }
                        else {
                            output.append(SET_BG_COLOR_DARK_GREY);
                        }
                    }
                    ChessPosition position = new ChessPositionImp(i, j);
                    ChessPiece piece = board.getPiece(position);
                    if(piece == null){
                        output.append(EMPTY);
                        continue;
                    }
                    else{
                        if(piece.getTeamColor() == ChessGame.TeamColor.WHITE){
                            switch(piece.getPieceType()){
                                case KING:
                                    output.append(SET_TEXT_COLOR_RED + WHITE_KING);
                                    break;
                                case QUEEN:
                                    output.append(SET_TEXT_COLOR_RED + WHITE_QUEEN);
                                    break;
                                case BISHOP:
                                    output.append(SET_TEXT_COLOR_RED + WHITE_BISHOP);
                                    break;
                                case KNIGHT:
                                    output.append(SET_TEXT_COLOR_RED + WHITE_KNIGHT);
                                    break;
                                case ROOK:
                                    output.append(SET_TEXT_COLOR_RED + WHITE_ROOK);
                                    break;
                                case PAWN:
                                    output.append(SET_TEXT_COLOR_RED + WHITE_PAWN);
                                    break;
                                default:
                                    output.append(SET_TEXT_COLOR_BLUE + EMPTY);
                                    break;
                            }
                        }
                        else if(piece.getTeamColor() == ChessGame.TeamColor.BLACK){
                            switch(piece.getPieceType()){
                                case KING:
                                    output.append(SET_TEXT_COLOR_BLACK + BLACK_KING);
                                    break;
                                case QUEEN:
                                    output.append(SET_TEXT_COLOR_BLACK + BLACK_QUEEN);
                                    break;
                                case BISHOP:
                                    output.append(SET_TEXT_COLOR_BLACK + BLACK_BISHOP);
                                    break;
                                case KNIGHT:
                                    output.append(SET_TEXT_COLOR_BLACK + BLACK_KNIGHT);
                                    break;
                                case ROOK:
                                    output.append(SET_TEXT_COLOR_BLACK + BLACK_ROOK);
                                    break;
                                case PAWN:
                                    output.append(SET_TEXT_COLOR_BLACK + BLACK_PAWN);
                                    break;
                                default:
                                    output.append(EMPTY);
                                    break;
                            }
                        }
                    }
                }
                output.append(SET_BG_COLOR_LIGHT_GREY + SET_TEXT_COLOR_WHITE + " ").append(i).append(" ").append("\n");
            }
            output.append(SET_BG_COLOR_LIGHT_GREY + SET_TEXT_COLOR_WHITE + EMPTY +
                    " a " + " b " + " c " + " d " + " e " + " f " + " g " + " h " + EMPTY + "\n");
        }
        return output.toString();
    }
}
