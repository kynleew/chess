package client;

public enum State {
    SIGNEDOUT,
    SIGNEDIN
}
