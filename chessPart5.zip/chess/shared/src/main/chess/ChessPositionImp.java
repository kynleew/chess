package chess;

import chess.ChessPosition;
import chess.ChessPiece;

import java.util.Objects;

public class ChessPositionImp implements ChessPosition {
    int row;
    int column;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ChessPositionImp that = (ChessPositionImp) o;
        return row == that.row && column == that.column;
    }

    @Override
    public int hashCode() {
        return Objects.hash(row, column);
    }

    public ChessPositionImp(int r, int c){
        this.row = r;
        this.column = c;
    }
    @Override
    public int getRow() {
        return row;
    }

    @Override
    public int getColumn() {
        return column;
    }
}
