package chess;

import java.util.Collection;
import java.util.HashSet;

public class ChessGameImp implements ChessGame {
    TeamColor color = TeamColor.WHITE;
    ChessBoardImp myBoard;
    ChessBoardImp tempBoard = new ChessBoardImp();
    Collection<ChessMove> moves = new HashSet<>();

    public ChessGameImp(ChessBoardImp thisBoard){
        myBoard = thisBoard;
    }
    public ChessGameImp(){
        myBoard = new ChessBoardImp();
    }

    @Override
    public TeamColor getTeamTurn() {
        return color;
    }

    @Override
    public void setTeamTurn(TeamColor team) {
        color = team;
    }

    @Override
    public Collection<ChessMove> validMoves(ChessPosition startPosition) {
        TeamColor teamColor = null;
        if(myBoard.getPiece(startPosition) != null){
            teamColor = myBoard.getPiece(startPosition).getTeamColor();
        }

        else if(myBoard.getPiece(startPosition) == null){
            return null;
        }
        Collection<ChessMove> validMoves = new HashSet<>();
        moves.clear();
        moves = myBoard.getPiece(startPosition).pieceMoves(myBoard, startPosition);
        for(ChessMove move : moves){
            if (!isMoveInCheck_Test(teamColor, move)) {
                validMoves.add(move);
            }
        }
        return validMoves;
    }



    @Override
    public void makeMove(ChessMove move) throws InvalidMoveException {
        int temp = 0;
        validMoves(move.getStartPosition());
        if(moves.isEmpty()){
            throw new InvalidMoveException("There are zero valid moves.");
        }
        else if(move.getStartPosition() == move.getEndPosition()){
            throw new InvalidMoveException("That is not a move, you are already in that position");
        }
        else if(!getTeamTurn().equals(myBoard.getPiece(move.getStartPosition()).getTeamColor())){
            throw new InvalidMoveException("You can't move that piece");
        }
        for (ChessMove checkMove : moves) {

            if(checkMove.getStartPosition().getColumn() != move.getStartPosition().getColumn() || checkMove.getStartPosition().getRow() != move.getStartPosition().getRow()){
                throw new InvalidMoveException("That is not where your piece start position is");
            }
            if (checkMove.getEndPosition().getRow() == move.getEndPosition().getRow() && checkMove.getEndPosition().getColumn() == move.getEndPosition().getColumn()) {
                ChessPosition endPosition = move.getEndPosition();
                ChessPosition startPosition = move.getStartPosition();

                ChessPiece oldPiece = myBoard.getPiece(move.getStartPosition());
                ChessPiece piece = getChessPiece(move, oldPiece);

                myBoard.addPiece(endPosition, piece);
                myBoard.removePiece(startPosition);

                if(isInCheck(color)){
                    myBoard.addPiece(startPosition, oldPiece);
                    myBoard.removePiece(endPosition);
                    throw new InvalidMoveException("Invalid move, get King out of check");
                }
                temp = 1;
                break;
            }
        }
        if(temp == 0){
            throw new InvalidMoveException("You can't move there");
        }
        if(getTeamTurn() == TeamColor.WHITE){
            setTeamTurn(TeamColor.BLACK);
        }
        else if(getTeamTurn() == TeamColor.BLACK){
            setTeamTurn(TeamColor.WHITE);
        }
    }

    private ChessPiece getChessPiece(ChessMove move, ChessPiece oldPiece) {
        ChessPiece piece = oldPiece;
        if(oldPiece.getPieceType() == ChessPiece.PieceType.PAWN) {
            ChessPiece.PieceType promotionPiece = move.getPromotionPiece();
            if(promotionPiece == ChessPiece.PieceType.QUEEN) piece = new Queen(color);
            else if(promotionPiece == ChessPiece.PieceType.ROOK) piece = new Rook(color);
            else if(promotionPiece == ChessPiece.PieceType.KNIGHT) piece = new Knight(color);
            else if(promotionPiece == ChessPiece.PieceType.BISHOP) piece = new Bishop(color);
        }
        return piece;
    }

    @Override
    public boolean isInCheck(TeamColor teamColor) {
        ChessPosition kingPosition = null;
        for(int i = 1; i < 9; i++){
            for(int j = 1; j < 9; j++){
                ChessPosition position = new ChessPositionImp(i,j);
                if(myBoard.getPiece(position) == null){
                    continue;
                }
                else if(myBoard.getPiece(position).getTeamColor() == teamColor){
                    kingPosition = findKingPosition(teamColor, myBoard);
                    return checkKingInCheck(teamColor, kingPosition, myBoard);
                }
            }
        }
        return checkKingInCheck(teamColor, kingPosition, myBoard);
    }

    @Override
    public boolean isInCheckmate(TeamColor teamColor){
        Collection<ChessMove> currTeamMoves;
        if(isInCheck(teamColor)){
            currTeamMoves = findOppositeTeamMoves(teamColor, myBoard);
            for(ChessMove move : currTeamMoves){
                testMovePiece(move);
                boolean isKingFound = checkKingInCheck(teamColor,
                        new ChessPositionImp(move.getEndPosition().getRow(), move.getEndPosition().getColumn()), myBoard); //Add opposite moves to set, return true if king position is found
                if(isKingFound){
                    return true;
                }
            }
            return true;
        }
        return false;
    }
    private void testMovePiece(ChessMove move){
        ChessPosition endPosition = move.getEndPosition();
        ChessPosition startPosition = move.getStartPosition();
        ChessPiece piece = tempBoard.getPiece(move.getStartPosition());
        tempBoard.addPiece(endPosition, piece);
        tempBoard.removePiece(startPosition);
    }
    public boolean isMoveInCheck_Test(TeamColor teamColor, ChessMove move) {
        ChessPosition kingPosition;
        ChessPosition startPosition = move.getStartPosition();
        ChessPosition endPosition = move.getEndPosition();
        ChessMove undoMove = new ChessMoveImp(endPosition, startPosition, null);
        boolean isMoveGoingToCheck = false;

        setTestBoard();
        testMovePiece(move);
        kingPosition = findKingPosition(teamColor, tempBoard);

        isMoveGoingToCheck = checkKingInCheck(teamColor, kingPosition, tempBoard);

        testMovePiece(undoMove);

        return isMoveGoingToCheck;
    }

    private boolean checkKingInCheck(TeamColor teamColor, ChessPosition kingPosition, ChessBoard board){
        Collection<ChessMove> allOpposingMoves;
        if(kingPosition == null) return false;
        allOpposingMoves = findOppositeTeamMoves(teamColor == TeamColor.WHITE ? TeamColor.BLACK: TeamColor.WHITE, board); //findTeamMoves edits myBoard
        return isKingHere(kingPosition, allOpposingMoves);
    }
    private boolean isKingHere(ChessPosition kingPosition, Collection<ChessMove> allOpposingMoves){
        boolean isKingInCheck = false;
        for(ChessMove move : allOpposingMoves){
            if (move.getEndPosition() != null) {
                if(move.getEndPosition().getRow() == kingPosition.getRow()){
                    if(move.getEndPosition().getColumn() == kingPosition.getColumn()){
                        isKingInCheck = true;
                    }
                }
            }
        }
        return isKingInCheck;
    }
    private Collection<ChessMove> findOppositeTeamMoves(TeamColor teamColor, ChessBoard board){
        Collection<ChessMove> tempMoves = new HashSet<>();
        Collection<ChessMove> allOpposingMoves = new HashSet<>();
        for(int i = 1; i < 9; i++){
            for(int j = 1; j < 9; j++) {
                ChessPosition position = new ChessPositionImp(i,j);
                if (board.getPiece(position) == null) {
                    continue;
                } else if (board.getPiece(position).getTeamColor() == teamColor) {
                    tempMoves = board.getPiece(position).pieceMoves(board, position);
                }
            }
            allOpposingMoves.addAll(tempMoves);
        }
//        System.out.println(board);
        return allOpposingMoves;
    }
    private void setTestBoard(){
        for(int i = 1; i < 9; i++) {
            for (int j = 1; j < 9; j++) {
                ChessPosition position = new ChessPositionImp(i,j);
                tempBoard.addPiece(position, myBoard.getPiece(position));
            }
        }
    }


    @Override
    public boolean isInStalemate(TeamColor teamColor) {
        boolean noMoves = false;
        Collection<ChessMove>validMoves = new HashSet<>();
        moves.clear();
        for(int i = 1; i < 9; i++){
            for(int j = 1; j < 9; j++){
                ChessPosition position = new ChessPositionImp(i,j);
                if(myBoard.getPiece(position) != null){
                    if(teamColor == myBoard.getPiece(position).getTeamColor()){
                        validMoves = validMoves(position);
                    }
                }


            }
        }
        return validMoves.isEmpty();
    }


    private ChessPosition findKingPosition(TeamColor teamColor, ChessBoard board){
        ChessPosition kingPosition = null;
        for(int i = 1; i < 9; i++) {
            for (int j = 1; j < 9; j++) {
                ChessPosition position = new ChessPositionImp(i,j);
                if(board.getPiece(position) == null)continue;
                else if(board.getPiece(position).getTeamColor() == teamColor){
                    if(board.getPiece(position).getPieceType() == ChessPiece.PieceType.KING){
                        kingPosition = new ChessPositionImp(i,j);
                    }
                }
            }
        }
        return kingPosition;
    }

    @Override
    public void setBoard(ChessBoard board) {myBoard = (ChessBoardImp) board;}

    @Override
    public ChessBoard getBoard() {return myBoard;}
}
