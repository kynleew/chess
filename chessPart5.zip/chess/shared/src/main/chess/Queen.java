package chess;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

public class Queen implements ChessPiece {
    ChessGameImp.TeamColor color;
    Set<ChessPosition> QueenTemp = new HashSet<>();
    Collection<ChessMove> moves = new HashSet<>();

    public Queen(ChessGameImp.TeamColor color){
        this.color = color;
    }
    @Override
    public ChessGameImp.TeamColor getTeamColor() {
        return color;
    }

    @Override
    public PieceType getPieceType() {
        return PieceType.QUEEN;
    }

    @Override
    public Collection<ChessMove> pieceMoves(ChessBoard board, ChessPosition myPosition) {
        int row = myPosition.getRow();
        int col = myPosition.getColumn();
        QueenTemp.clear();

        checkMoves(board, row, col, 1, 1);
        checkMoves(board, row, col, 1, -1);
        checkMoves(board, row, col, -1, 1);
        checkMoves(board, row, col, -1, -1);
        checkMoves(board, row, col, 1, 0);
        checkMoves(board, row, col, -1, 0);
        checkMoves(board, row, col, 0, 1);
        checkMoves(board, row, col, 0, -1);

        Collection<ChessMove> thisMoves = new HashSet<>();
        for(ChessPosition position: QueenTemp){
            ChessMoveImp move = new ChessMoveImp(myPosition, position, null);
            thisMoves.add(move);
        }
        return thisMoves;
    }
    private void checkMoves(ChessBoard board, int row, int col, int x, int y){
        if(row + x <= 0 || col + y <= 0) return;
        else if(row + x >= 9 || col + y >= 9) return;
        else if(row == 1 && x < 0) return;
        else if(row == 8 && x > 0) return;
        else if(col == 1 && y < 0) return;
        else if(col == 8 && y > 0) return;

        //y=1
        if(x == -1 && y > 0){
            for(int j = 0; j < (8-col); j++){
                ChessPosition position = new ChessPositionImp(row+x,col+y);
                if((position.getRow() > 8) || position.getColumn() > 8) break;
                if((position.getRow() > 8) || position.getColumn() < 1) break;
                if((position.getRow() < 1) || position.getColumn() > 8) break;
                if((position.getRow() < 1) || position.getColumn() < 1) break;
                if(board.getPiece(position) == null){
                    QueenTemp.add(position);
                    y++;
                    x--;
                }
                else if(board.getPiece(position).getTeamColor() != getTeamColor()){
                    QueenTemp.add(position);
                    break;
                }
                else{
                    break;
                }
            }
        }
        //x=-1
        if(x == -1 && y <= 0){
            for(int j = 7; j > (8-row); j--){
                ChessPosition position = new ChessPositionImp(row+x,col+y);
                if((position.getRow() > 8) || position.getColumn() > 8) break;
                if((position.getRow() > 8) || position.getColumn() < 1) break;
                if((position.getRow() < 1) || position.getColumn() > 8) break;
                if((position.getRow() < 1) || position.getColumn() < 1) break;
                else if(board.getPiece(position) == null){
                    QueenTemp.add(position);
                    x--;
                    if(y < 0){
                        y--;
                    }

                }
                else if(board.getPiece(position).getTeamColor() != getTeamColor()){
                    QueenTemp.add(position);
                    break;
                }
                else{
                    break;
                }
            }
        }
        //X=1
        if(x == 1 && y >= 0){
            for(int j = 0; j < (8-row); j++){
                ChessPosition position = new ChessPositionImp(row+x,col+y);
                if((position.getRow() > 8) || position.getColumn() > 8) break;
                if((position.getRow() > 8) || position.getColumn() < 1) break;
                if((position.getRow() < 1) || position.getColumn() > 8) break;
                if((position.getRow() < 1) || position.getColumn() < 1) break;
                else if(board.getPiece(position) == null){
                    QueenTemp.add(position);
                    x++;
                    if(y > 0){
                        y++;
                    }

                }
                else if(board.getPiece(position).getTeamColor() != getTeamColor()){
                    QueenTemp.add(position);
                    break;
                }
                else{
                    break;
                }
            }
        }
        //y=-1
        if(x == 1 && y < 0){
            for(int j = 7; j > (8-col); j--){
                ChessPosition position = new ChessPositionImp(row+x,col+y);
                if((position.getRow() > 8) || position.getColumn() > 8) break;
                if((position.getRow() > 8) || position.getColumn() < 1) break;
                if((position.getRow() < 1) || position.getColumn() > 8) break;
                if((position.getRow() < 1) || position.getColumn() < 1) break;
                else if(board.getPiece(position) == null){
                    QueenTemp.add(position);
                    y--;
                    x++;
                }
                else if(board.getPiece(position).getTeamColor() != getTeamColor()){
                    QueenTemp.add(position);
                    break;
                }
                else{
                    break;
                }
            }
        }
        if(x == 0 && y == 1){
            for(int j = 0; j < (8-col); j++){
                ChessPosition position = new ChessPositionImp(row+x,col+y);
                if((position.getRow() > 8) || position.getColumn() > 8) break;
                if((position.getRow() > 8) || position.getColumn() < 1) break;
                if((position.getRow() < 1) || position.getColumn() > 8) break;
                if((position.getRow() < 1) || position.getColumn() < 1) break;
                else if(board.getPiece(position) == null){
                    QueenTemp.add(position);
                    y++;
                }
                else if(board.getPiece(position).getTeamColor() != getTeamColor()){
                    QueenTemp.add(position);
                    break;
                }
                else{
                    break;
                }
            }
        }
        //x=-1
        if(x == 0 && y == -1){
            for(int j = 7; j > (8-col); j--){
                ChessPosition position = new ChessPositionImp(row+x,col+y);
                if((position.getRow() > 8) || position.getColumn() > 8) break;
                if((position.getRow() > 8) || position.getColumn() < 1) break;
                if((position.getRow() < 1) || position.getColumn() > 8) break;
                if((position.getRow() < 1) || position.getColumn() < 1) break;
                else if(board.getPiece(position) == null){
                    QueenTemp.add(position);
                    y--;
                }
                else if(board.getPiece(position).getTeamColor() != getTeamColor()){
                    QueenTemp.add(position);
                    break;
                }
                else{
                    break;
                }
            }
        }
    }
}
