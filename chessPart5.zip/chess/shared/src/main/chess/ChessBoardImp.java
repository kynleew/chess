package chess;

public class ChessBoardImp implements ChessBoard {

    private ChessPiece[][] board;
    private ChessPiece piece;

    public ChessBoardImp(){
        board = new ChessPiece [8][8];
        piece = null;
    }
    @Override
    public void addPiece(ChessPosition position, ChessPiece piece) {
        board[position.getRow()-1][position.getColumn()-1] = piece;
    }

    public void removePiece(ChessPosition position){
        board[position.getRow()-1][position.getColumn()-1] = null;
    }

    @Override
    public ChessPiece getPiece(ChessPosition position) {
        piece = board[position.getRow()-1][position.getColumn()-1];
        return piece;
    }

    @Override
    public void resetBoard() {
        for(int i = 0; i < 8; i++){
            for(int j = 0; j < 8; j++){
                board[i][j] = null;
            }
        }
        //Set White Pawns
        for(int i = 0; i < 8; i++) board[1][i] = new Pawn(ChessGameImp.TeamColor.WHITE);
        //Set Black Pawns
        for(int i = 0; i < 8; i++) board[6][i] = new Pawn(ChessGameImp.TeamColor.BLACK);

//        Set White Pieces
        board[0][0] = new Rook(ChessGameImp.TeamColor.WHITE);
        board[0][1] = new Knight(ChessGameImp.TeamColor.WHITE);
        board[0][2] = new Bishop(ChessGameImp.TeamColor.WHITE);
        board[0][3] = new Queen(ChessGameImp.TeamColor.WHITE);
        board[0][4] = new King(ChessGameImp.TeamColor.WHITE);
        board[0][5] = new Bishop(ChessGameImp.TeamColor.WHITE);
        board[0][6] = new Knight(ChessGameImp.TeamColor.WHITE);
        board[0][7] = new Rook(ChessGameImp.TeamColor.WHITE);
//        Set Black Pieces
        board[7][0] = new Rook(ChessGameImp.TeamColor.BLACK);
        board[7][1] = new Knight(ChessGameImp.TeamColor.BLACK);
        board[7][2] = new Bishop(ChessGameImp.TeamColor.BLACK);
        board[7][3] = new Queen(ChessGameImp.TeamColor.BLACK);
        board[7][4] = new King(ChessGameImp.TeamColor.BLACK);
        board[7][5] = new Bishop(ChessGameImp.TeamColor.BLACK);
        board[7][6] = new Knight(ChessGameImp.TeamColor.BLACK);
        board[7][7] = new Rook(ChessGameImp.TeamColor.BLACK);

        //Look at curr board
//        System.out.println(this.toString());
    }

    public String toString(){
        StringBuilder output = new StringBuilder();
        for(int i = 7; i > -1; i--){
            for(int j = 0; j < 8; j++){
                ChessPiece piece = board[i][j];
                output.append('|');
                if(piece == null){
                    output.append(' ');
                    continue;
                }
                else{
//                    ChessPosition position = new ChessPositionImp(i,j);

                    if(piece.getTeamColor() == ChessGame.TeamColor.WHITE){
                        switch(piece.getPieceType()){
                            case KING:
                                output.append('K');
                                break;
                            case QUEEN:
                                output.append('Q');
                                break;
                            case BISHOP:
                                output.append('B');
                                break;
                            case KNIGHT:
                                output.append('N');
                                break;
                            case ROOK:
                                output.append('R');
                                break;
                            case PAWN:
                                output.append('P');
                                break;
                            default:
                                output.append('?');
                                break;
                        }
                    }
                    else if(piece.getTeamColor() == ChessGame.TeamColor.BLACK){
                        switch(piece.getPieceType()){
                            case KING:
                                output.append('k');
                                break;
                            case QUEEN:
                                output.append('q');
                                break;
                            case BISHOP:
                                output.append('b');
                                break;
                            case KNIGHT:
                                output.append('n');
                                break;
                            case ROOK:
                                output.append('r');
                                break;
                            case PAWN:
                                output.append('p');
                                break;
                            default:
                                output.append('?');
                                break;
                        }
                    }
                }
            }
            output.append('|');
            output.append('\n');
        }
        return output.toString();
    }
}
