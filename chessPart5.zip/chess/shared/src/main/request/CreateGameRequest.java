package request;

import result.CreateGameResult;

/**
 * CreateGameRequest will send a request to create a new game
 */
public class CreateGameRequest {
    /**
     * CreateGameRequest initialized the new request.
     */
    String gameName;
    public CreateGameRequest() {

    }

    public CreateGameRequest(String gameName) {
        this.gameName = gameName;
    }

    /**
     *
     * @return the name of the game you want to create
     */
    public String getGameName() {
        return gameName;
    }

    /**
     *
     * @param gameName is the projected name of the game
     */
    public void setGameName(String gameName) {
        this.gameName = gameName;
    }
}
