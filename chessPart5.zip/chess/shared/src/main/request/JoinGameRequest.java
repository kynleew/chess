package request;
import chess.ChessGame;

/**
 * JoinGameRequest is the request to join a game. It sends the request to the server.
 */
public class JoinGameRequest {
    private ChessGame.TeamColor playerColor;
    private int gameID;

    /**
     * JoinGameRequest initializes a new request for joining a game
     */
    public JoinGameRequest(){}

    public JoinGameRequest(ChessGame.TeamColor playerColor, int gameID) {
        this.playerColor = playerColor;
        this.gameID = gameID;
    }

    /**
     *
     * @return the team color of the player
     */
    public ChessGame.TeamColor getPlayerColor() {return playerColor;}

    /**
     *
     * @param playerColor sets the player with a color
     */
    public void setPlayerColor(ChessGame.TeamColor playerColor) {
        this.playerColor = playerColor;
    }

    /**
     *
     * @return the gameID that specifies what game it is
     */
    public int getGameID() {
        return gameID;
    }

    /**
     *
     * @param gameID identifies what game it is
     */
    public void setGameID(int gameID) {
        this.gameID = gameID;
    }
}
