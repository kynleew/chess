package result;

import models.Game;

import java.util.HashSet;

/**
 * ListGameResult holds all the information of a request
 */
public class ListGameResult {
    String message;
    Game game;
    HashSet<Game>games;
    String blackUsername;
    String whiteUsername;

    /**
     * ListGameResult initializes a new result
     */
    public ListGameResult() {
    }

    /**
     *
     * @return the message of failure or success
     */
    public String getMessage() {
        return message;
    }
    /**
     *
     * @param message is the message if it was a failure or success
     */
    public void setMessage(String message) {
        this.message = message;
    }
    /**
     *
     * @return the game to list
     */
    public Game getGame() {
        return game;
    }
    public HashSet<Game> getGames(){return games;}
    /**
     *
     * @param game the game you want to list
     */
    public void setGame(Game game) {
        this.game = game;
    }
    public void setGames(HashSet<Game> games) {
        this.games = games;
    }

}
