package result;

import chess.ChessGame;


/**
 * JoinGameResult tells you if you successfully joined a game or not
 */
public class JoinGameResult {
    private String message;
    ChessGame.TeamColor playerColor;

    public ChessGame.TeamColor getPlayerColor() {return playerColor;}

    /**
     *
     * @param playerColor sets the player with a color
     */
    public void setPlayerColor(ChessGame.TeamColor playerColor) {
        this.playerColor = playerColor;
    }

    /**
     * JoinGameResult initializes a new result
     */
    public JoinGameResult() {
    }

    /**
     *
     * @return the message of success or failure
     */
    public String getMessage() {
        return message;
    }

    /**
     *
     * @param message is the message of if it was sucessful or not
     */
    public void setMessage(String message) {
        this.message = message;
    }
}
