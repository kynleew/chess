package result;

/**
 * Stores result of signing up a new user
 */
public class RegisterResult {
    private String message;
    private String authToken;
    private String username;

    /**
     * Creates a new result instance
     */
    public RegisterResult() {
    }

    /**
     *
     * @return of success or failure
     */
    public String getMessage() {
        return message;
    }

    /**
     *
     * @param message of success or failure
     */
    public void setMessage(String message) {
        this.message = message;
    }

    /**
     *
     * @return authToken
     */
    public String getAuthToken() {
        return authToken;
    }

    /**
     *
     * @param authToken of new user
     */
    public void setAuthToken(String authToken) {
        this.authToken = authToken;
    }

    /**
     *
     * @return the new user username
     */
    public String getUsername() {
        return username;
    }

    /**
     *
     * @param username of the new user
     */
    public void setUsername(String username) {
        this.username = username;
    }
}
