package server;

//import exception.ResponseException;


import chess.ChessGame;
import com.google.gson.Gson;
import exception.ResponseException;
import models.*;
import request.CreateGameRequest;
import request.JoinGameRequest;
import request.LoginRequest;
import request.RegisterRequest;
import result.LoginResult;
import result.RegisterResult;
import result.*;


import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.*;

public class ServerFacade {

    //Testing the ServerFacade
//    public static void main(String [] args) throws ResponseException {
//        ServerFacade serverFacade = new ServerFacade("http://localhost:8082");
//        serverFacade.clear();
//        serverFacade.registerUser(new RegisterRequest("testuser", "password", "myEmail"));
//        RegisterRequest request = new RegisterRequest("Mckynlee", "dontTellAnyone", "email@thisismyemail.com");
//        serverFacade.registerUser(request);
//        serverFacade.login(new LoginRequest("Mckynlee", "dontTellAnyone"));
//
//        LoginResult result = serverFacade.login(new LoginRequest("testuser", "password"));
//        serverFacade.logout(result.getAuthToken());
//        result = serverFacade.login(new LoginRequest("Mckynlee", "dontTellAnyone"));
//        CreateGameResult gameResult =  serverFacade.createGame(new CreateGameRequest("newGameForMcKynlee"), result.getAuthToken());
//        serverFacade.createGame(new CreateGameRequest("game2"), result.getAuthToken());
//        serverFacade.joinGame(new JoinGameRequest(ChessGame.TeamColor.WHITE, gameResult.getGameID()), result.getAuthToken());
//        serverFacade.listGames(result.getAuthToken());
//    }
    private final String serverUrl;

    public ServerFacade(String url){
        serverUrl = url;
    }

//    public static LoginResult login(LoginRequest request) {
//        try {
//            //Make request is similar to HttpClient
//            String response = HttpClient.post(SERVER_URL+"/session", gson.toJson(request), "");
//            return gson.fromJson(response, UserResult.class);
//        } catch (Exception e) {
//            throw new RuntimeException("Login failed, " + makeErrorReadable(e));
//        }
//    }

    public RegisterResult registerUser(RegisterRequest request) throws ResponseException {
        var path = "/user";
        return this.makeRequest("POST", path, request, null, RegisterResult.class);
    }
    public LoginResult login(LoginRequest request) throws ResponseException {
        var path = "/session";
        return this.makeRequest("POST", path, request, null, LoginResult.class);
    }
    public LogoutResult logout(String authToken) throws ResponseException {
        var path = "/session";
        return this.makeRequest("DELETE", path, null, authToken, LogoutResult.class);
    }
    public ListGameResult listGames(String headers) throws ResponseException {
        var path = "/game";
        return this.makeRequest("GET", path, null, headers, ListGameResult.class);
    }
    public CreateGameResult createGame(CreateGameRequest request, String headers) throws ResponseException {
        var path = "/game";
        return this.makeRequest("POST", path, request, headers, CreateGameResult.class);
    }
    public JoinGameResult joinGame(JoinGameRequest request, String headers) throws ResponseException {
        var path = "/game";
        //Something with headers?
        return this.makeRequest("PUT", path, request, headers, JoinGameResult.class);
    }
    public ClearResult clear() throws ResponseException {
        var path = "/db";
        return this.makeRequest("DELETE", path, null,null, ClearResult.class);
    }



    //pass in json and return json
    private <T> T makeRequest(String method, String path, Object request, String authToken, Class<T> responseClass) throws ResponseException {
        try{
            URL url = (new URI(serverUrl + path)).toURL();
            HttpURLConnection http = (HttpURLConnection) url.openConnection();
            http.setRequestMethod(method);
            http.setDoOutput(true);
            http.addRequestProperty("Authorization", authToken);
            writeBody(request, http);
            http.connect();
            throwIfNotSuccessful(http);
            return readBody(http, responseClass);

        }catch (Exception ex){
            throw new ResponseException(500, ex.getMessage());
        }
    }


    private <T> T readBody(HttpURLConnection http, Class<T> responseClass) throws IOException{
        T response = null;
        Gson gson = new Gson();
        if(http.getContentLength() < 0){
            try(InputStream respBody = http.getInputStream()){
                InputStreamReader reader = new InputStreamReader(respBody);
                if(responseClass != null){
                    response = gson.fromJson(reader, responseClass);
//                    response = ModelSerializer.deserialize(reader, responseClass); //QUESTION ABOUT THIS
                }
            }
        }
        return response;
    }

    private void throwIfNotSuccessful(HttpURLConnection http) throws IOException, ResponseException{
        var status = http.getResponseCode();
        if(!isSuccessful(status)){
            throw new ResponseException(status, "failure: " + status);
        }
    }

    private boolean isSuccessful(int status) {
        return status / 100 == 2;
    }

    private void writeBody(Object request, HttpURLConnection http) throws IOException{
        if(request != null){
            http.addRequestProperty("content-Type", "application/json");
            String reqData = new Gson().toJson(request);
            try(OutputStream reqBody = http.getOutputStream()){
                reqBody.write(reqData.getBytes());
            }
        }
    }
}
