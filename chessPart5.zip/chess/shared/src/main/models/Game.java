package models;
import chess.ChessBoardImp;
import chess.ChessGame;
import chess.ChessGameImp;
import result.CreateGameResult;

/**
 * Game is where we keep track of the teamColor and the player
 * that is related to that color.
 */
public class Game {
    int gameID;
    String whiteUsername;
    String blackUsername;
    String gameName;
    ChessGameImp game;
    ChessBoardImp board;

    /**
     * Creates a new Game with the users
//     * @param gameID is the unique number of the individual game
//     * @param whiteUsername assigns a players username to white
//     * @param blackUsername assigns a players username to black
//     * @param game is the specific ChessGame that the two players are playing on
     */
    public Game(String gameName) {
        whiteUsername = null;
        blackUsername = null;
        game = new ChessGameImp();
        this.gameName = gameName;
        board = new ChessBoardImp();
        board.resetBoard();
        game.setBoard(board);
    }

    public Game(String gameName, String blackUsername, String whiteUsername, ChessBoardImp thisGame){
        this.whiteUsername = whiteUsername;
        this.blackUsername = blackUsername;
        this.gameName = gameName;
        this.game = new ChessGameImp(thisGame);
    }

    public void setWhiteUsername(String whiteUsername) {
        this.whiteUsername = whiteUsername;
    }

    public void setBlackUsername(String blackUsername) {
        this.blackUsername = blackUsername;
    }

    public int getGameID() {
        return gameID;
    }
    public void setGameID(int gameID){
        this.gameID = gameID;
    }

    public String getWhiteUsername() {
        return whiteUsername;
    }

    public String getBlackUsername() {
        return blackUsername;
    }

    public ChessGame getGame() {
        return game;
    }
    public String getGameName(){return gameName;}
}
