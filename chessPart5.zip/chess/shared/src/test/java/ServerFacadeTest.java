import exception.ResponseException;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import server.ServerFacade;
import request.RegisterRequest;
import request.*;
import result.*;
import chess.*;

public class ServerFacadeTest {
    ServerFacade serverFacade;
    @BeforeEach
    void setup() throws ResponseException {
        serverFacade = new ServerFacade("http://localhost:8082");
        serverFacade.clear();
        RegisterRequest request = new RegisterRequest("testuser", "password", "email");
        serverFacade.registerUser(request);
    }
    @Test
    void register() throws ResponseException {
        RegisterRequest request = new RegisterRequest("Mckynlee", "dontTellAnyone", "email@thisismyemail.com");
        RegisterResult regResult = serverFacade.registerUser(request);
        Assertions.assertEquals("Mckynlee", regResult.getUsername());
        Assertions.assertEquals("", regResult.getMessage(), "Status code was not 200");
    }
    @Test
    void negRegister() throws ResponseException{
        RegisterRequest request = new RegisterRequest("donald", "duck", "email");
        serverFacade.registerUser(request);
        RegisterRequest requestAgain = new RegisterRequest("donald", "duck", "email");
        Assertions.assertThrows(ResponseException.class, ()->{serverFacade.registerUser(requestAgain);});
    }
    @Test
    void login() throws ResponseException {
        RegisterRequest request = new RegisterRequest("donald", "duck", "email");
        serverFacade.registerUser(request);
        LoginResult result1 = serverFacade.login(new LoginRequest("donald", "duck"));
        Assertions.assertEquals("donald", result1.getUsername());

        //negative login
        Assertions.assertThrows(ResponseException.class, ()->{serverFacade.login(new LoginRequest("invalidUser", "invalidPassword"));});
    }
    @Test
    void logout() throws ResponseException {
        LoginResult result = serverFacade.login(new LoginRequest("testuser", "password"));
        LogoutResult logoutResult = serverFacade.logout(result.getAuthToken());
        Assertions.assertEquals("", logoutResult.getMessage());
        Assertions.assertThrows(ResponseException.class, ()->{serverFacade.logout("invalidAuthToken");});
    }
    @Test
    void createGame() throws ResponseException {
        LoginResult result = serverFacade.login(new LoginRequest("testuser", "password"));
        CreateGameResult gameResult =  serverFacade.createGame(new CreateGameRequest("newGameForMcKynlee"), result.getAuthToken());
        serverFacade.createGame(new CreateGameRequest("game2"), result.getAuthToken());

        // Negative create game (invalid auth token)
        Assertions.assertThrows(ResponseException.class, ()->{serverFacade.createGame(new CreateGameRequest("invalidGame"), "invalidAuthToken");});
    }
    @Test
    void joinGame() throws ResponseException {
        LoginResult result = serverFacade.login(new LoginRequest("testuser", "password"));
        CreateGameResult gameResult =  serverFacade.createGame(new CreateGameRequest("newGameForMcKynlee"), result.getAuthToken());
        JoinGameResult joinResult = serverFacade.joinGame(new JoinGameRequest(ChessGame.TeamColor.WHITE, gameResult.getGameID()), result.getAuthToken());

        // Negative join game (invalid game ID)
        Assertions.assertThrows(ResponseException.class, ()->{serverFacade.joinGame(new JoinGameRequest(ChessGame.TeamColor.BLACK, 100), result.getAuthToken());});
    }
    @Test
    void listGames() throws ResponseException {
        LoginResult result = serverFacade.login(new LoginRequest("testuser", "password"));
        ListGameResult listResult = serverFacade.listGames(result.getAuthToken());

        // Negative list games (invalid auth token)
        Assertions.assertThrows(ResponseException.class, ()->{serverFacade.listGames("invalidAuthToken");});
    }
    @Test
    void clear() throws ResponseException {
        ClearResult clearResult = serverFacade.clear();
    }
}
